My resource pack

Enable the resource pack, then use these commands:

coffee_grounds_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:coffee_grounds_silhouette_c9b8c1a1"]

nori_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:nori_silhouette_1a1423c4"]

salt_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:salt_silhouette_df5d22d4"]

flour_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:flour_silhouette_87bbd513"]

Orange Kitchen Coffee Grounds: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_coffee_grounds_9a9a288c"]

Orange Kitchen Cucumber Seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_cucumber_seeds_c74f3290"]

Orange Kitchen Tomato Seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_tomato_seeds_c81f8ec1"]

Orange Kitchen Strawberry Seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_strawberry_seeds_e4cc466e"]

Orange Kitchen Salt: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_salt_3ce5a5a4"]

Orange Kitchen Soy Seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_soy_seeds_6e58bd5a"]

Orange Kitchen Rice Seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_rice_seeds_4534eb32"]

Orange Kitchen Orange Seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_orange_seeds_8b40998d"]

Orange Kitchen Nori: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_nori_8e1502f0"]

Orange Kitchen Onion Seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_onion_seeds_baee709f"]

Orange Kitchen Lemon Seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_lemon_seeds_89209f20"]

Orange Kitchen Lettuce Seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_lettuce_seeds_1c6de5fb"]

Orange Kitchen Garlic Seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_garlic_seeds_3be71124"]

Orange Kitchen Coffee Seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_coffee_seeds_26270daf"]

Orange Kitchen Corn Seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_corn_seeds_8de898fc"]

Orange Kitchen Chilli Seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_chilli_seeds_2a97367b"]

Orange Kitchen Flour: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_flour_4e5ac843"]



Java target: 1.21.4 item model format (pack format 46 by default). A custom block asset is an item/display model unless a vanilla texture binding is set.