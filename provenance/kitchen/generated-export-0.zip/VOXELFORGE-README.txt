My resource pack

Enable the resource pack, then use these commands:

Orange Kitchen Pork Dumplings: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_pork_dumplings_cc2d2ed0"]

Orange Kitchen Beef Noodles: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_beef_noodles_4ca3fb99"]

Orange Kitchen Vegetable Noodles: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_vegetable_noodles_a41d57d3"]

Orange Kitchen Chicken Fried Rice: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_chicken_fried_rice_8ded6fcf"]

Orange Kitchen Egg Fried Rice: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_egg_fried_rice_4bcb09a0"]

Orange Kitchen Spicy Ramen: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_spicy_ramen_e37a18d0"]

Orange Kitchen Mushroom Ramen: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mushroom_ramen_b1994bf6"]

Orange Kitchen Chicken Ramen: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_chicken_ramen_7cf8f87e"]

Orange Kitchen Pancakes: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_pancakes_a4dbe27d"]

Orange Kitchen Chocolate Cake: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_chocolate_cake_572839b7"]

Orange Kitchen Strawberry Cake: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_strawberry_cake_94f04285"]

Orange Kitchen Berry Pie: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_berry_pie_d0c1e5b4"]

Orange Kitchen Apple Pie: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_apple_pie_e355948a"]

Orange Kitchen Chocolate Cookie: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_chocolate_cookie_a9c9e0a1"]

Orange Kitchen Sweet Roll: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_sweet_roll_b78a5073"]

Orange Kitchen Strawberry Doughnut: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_strawberry_doughnut_cae6bfc2"]

Orange Kitchen Chocolate Doughnut: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_chocolate_doughnut_a14c1816"]

Orange Kitchen Glazed Doughnut: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_glazed_doughnut_f1d39505"]

Orange Kitchen Chocolate Croissant: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_chocolate_croissant_1d32bab4"]

Orange Kitchen Croissant: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_croissant_afd2b9a1"]

Orange Kitchen Garlic Bread: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_garlic_bread_e4425e9b"]

Orange Kitchen Calzone: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_calzone_562611ed"]

Orange Kitchen Chilli Pizza: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_chilli_pizza_af24d0b7"]

Orange Kitchen Bbq Chicken Pizza: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_bbq_chicken_pizza_9d19d552"]

Orange Kitchen Garden Pizza: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_garden_pizza_ab3ea874"]

Orange Kitchen Mushroom Pizza: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mushroom_pizza_27c1b204"]

Orange Kitchen Pepperoni Pizza: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_pepperoni_pizza_a7e7edc8"]

Orange Kitchen Margherita Pizza: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_margherita_pizza_791e2a61"]

Orange Kitchen Sushi Platter: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_sushi_platter_63b4762c"]

Orange Kitchen Vegetable Tempura: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_vegetable_tempura_fbb43069"]

Orange Kitchen Salmon Onigiri: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_salmon_onigiri_b3eb3eab"]

Orange Kitchen Onigiri: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_onigiri_30c4ed62"]

Orange Kitchen Garden Roll: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_garden_roll_a1afef0a"]

Orange Kitchen Spicy Salmon Roll: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_spicy_salmon_roll_c4cbf9c4"]

Orange Kitchen Salmon Maki: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_salmon_maki_3edd8b43"]

Orange Kitchen Cucumber Maki: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_cucumber_maki_d91828b6"]

Orange Kitchen Cod Nigiri: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_cod_nigiri_1a91c9f1"]

Orange Kitchen Salmon Nigiri: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_salmon_nigiri_c7dde387"]

Orange Kitchen Fish Burger: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_fish_burger_d1790235"]

Orange Kitchen Chicken Nuggets: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_chicken_nuggets_85ec8773"]

Orange Kitchen Onion Rings: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_onion_rings_9eda063f"]

Orange Kitchen Loaded Fries: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_loaded_fries_7a10e84f"]

Orange Kitchen Fries: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_fries_22c1d3ca"]

Orange Kitchen Chilli Dog: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_chilli_dog_8de857ce"]

Orange Kitchen Hot Dog: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_hot_dog_a26b528f"]

Orange Kitchen Veggie Burger: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_veggie_burger_074ff549"]

Orange Kitchen Spicy Chicken Burger: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_spicy_chicken_burger_6145f613"]

Orange Kitchen Chicken Burger: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_chicken_burger_c2a8669d"]

Orange Kitchen Double Burger: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_double_burger_dcfdabc7"]

Orange Kitchen Cheeseburger: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_cheeseburger_1d9cb148"]

Orange Kitchen Coffee Grounds: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_coffee_grounds_181f93e6"]

Orange Kitchen Pulled Pork: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_pulled_pork_711f4354"]

Orange Kitchen Fried Fish: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_fried_fish_e4f1d1b0"]

Orange Kitchen Fried Chicken: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_fried_chicken_b9acbc9c"]

Orange Kitchen Cooked Chicken: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_cooked_chicken_94789c47"]

Orange Kitchen Sushi Rice: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_sushi_rice_82e71ef6"]

Orange Kitchen Bbq Sauce: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_bbq_sauce_5b99b7d6"]

Orange Kitchen Sliced Potato: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_sliced_potato_ee06c26f"]

Orange Kitchen Pepperoni: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_pepperoni_24137ba2"]

Orange Kitchen Grilled Sausage: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_grilled_sausage_251bc692"]

Orange Kitchen Broth: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_broth_310d9b3f"]

Orange Kitchen Chocolate: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_chocolate_14035af6"]

Orange Kitchen Cream: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_cream_09969b8b"]

Orange Kitchen Soy Sauce: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_soy_sauce_f957184b"]

Orange Kitchen Hot Sauce: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_hot_sauce_ec0e7512"]

Orange Kitchen Tomato Sauce: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_tomato_sauce_aa0be91f"]

Orange Kitchen Pizza Base: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_pizza_base_60bf40ae"]

Orange Kitchen Noodles: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_noodles_ab978818"]

Orange Kitchen Bun: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_bun_7fefac2b"]

Orange Kitchen Cooked Burger Patty: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_cooked_burger_patty_4c3bfcdd"]

Orange Kitchen Raw Patty: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_raw_patty_e8b951c4"]

Orange Kitchen Minced Beef: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_minced_beef_c239ec79"]

Orange Kitchen Cod Slice: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_cod_slice_1f2884d9"]

Orange Kitchen Salmon Slice: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_salmon_slice_a363ea3d"]

Orange Kitchen Nori: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_nori_b0cf2361"]

Orange Kitchen Cooked Rice: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_cooked_rice_6641ba3e"]

Orange Kitchen Breadcrumbs: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_breadcrumbs_a2fa1b42"]

Orange Kitchen Batter: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_batter_33a598b3"]

Orange Kitchen Dough: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_dough_5c5911e6"]

Orange Kitchen Cheese: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_cheese_5bd3da1b"]

Orange Kitchen Butter: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_butter_e8480aa6"]

Orange Kitchen Salt: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_salt_90fae7df"]

Orange Kitchen Flour: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_flour_eac48326"]

Orange Kitchen Garlic Seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_garlic_seeds_40ed2a44"]

Orange Kitchen Garlic: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_garlic_8e1d5374"]

Orange Kitchen Lemon Seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_lemon_seeds_08c696a3"]

Orange Kitchen Lemon: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_lemon_98a0f609"]

Orange Kitchen Orange Seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_orange_seeds_e2183e6b"]

Orange Kitchen Orange: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_orange_8a7f2734"]

Orange Kitchen Coffee Seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_coffee_seeds_32aa37ca"]

Orange Kitchen Coffee: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_coffee_defb4163"]

Orange Kitchen Soy Seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_soy_seeds_b9389802"]

Orange Kitchen Soy: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_soy_834deaf6"]

Orange Kitchen Strawberry Seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_strawberry_seeds_603d72d5"]

Orange Kitchen Strawberry: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_strawberry_7e6735ac"]

Orange Kitchen Corn Seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_corn_seeds_6e22fad1"]

Orange Kitchen Corn: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_corn_c7923979"]

Orange Kitchen Cucumber Seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_cucumber_seeds_d5f8f76b"]

Orange Kitchen Cucumber: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_cucumber_89df35f6"]

Orange Kitchen Chilli Seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_chilli_seeds_60653306"]

Orange Kitchen Chilli: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_chilli_ac20070e"]

Orange Kitchen Rice Seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_rice_seeds_54834c7a"]

Orange Kitchen Rice: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_rice_03011044"]

Orange Kitchen Onion Seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_onion_seeds_a3c6392f"]

Orange Kitchen Onion: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_onion_ba5ff480"]

Orange Kitchen Lettuce Seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_lettuce_seeds_630e8684"]

Orange Kitchen Lettuce: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_lettuce_553c618c"]

Orange Kitchen Tomato Seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_tomato_seeds_b1f1245d"]

Orange Kitchen Tomato: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_tomato_562c3179"]

Orange Kitchen Takeaway Bag: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_takeaway_bag_55b3f4cc"]

Orange Kitchen Plate: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_plate_a88d7712"]

Orange Kitchen Cookbook: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_cookbook_594d844b"]

Orange Kitchen Coffee Machine: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_coffee_machine_f0d07748"]

Orange Kitchen Blender: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_blender_cf231698"]

Orange Kitchen Smoker: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_smoker_3f350a1c"]

Orange Kitchen Steamer: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_steamer_479c2417"]

Orange Kitchen Wok: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_wok_ecd634bf"]

Orange Kitchen Stockpot: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_stockpot_9fde4eee"]

Orange Kitchen Baking Oven: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_baking_oven_8014e1da"]

Orange Kitchen Pizza Oven: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_pizza_oven_b6759d9a"]

Orange Kitchen Dough Bench: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_dough_bench_6b55a9c2"]

Orange Kitchen Sushi Counter: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_sushi_counter_cb7df471"]

Orange Kitchen Rice Cooker: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_rice_cooker_2cffe05f"]

Orange Kitchen Deep Fryer: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_deep_fryer_7b9cb06b"]

Orange Kitchen Griddle: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_griddle_601e1990"]

Orange Kitchen Mixing Bowl: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mixing_bowl_dac012af"]

Orange Kitchen Chopping Board: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_chopping_board_46a46e8f"]

Orange Kitchen Prep Counter: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_prep_counter_f293f87a"]



Java target: 1.21.4 item model format (pack format 46 by default). A custom block asset is an item/display model unless a vanilla texture binding is set.