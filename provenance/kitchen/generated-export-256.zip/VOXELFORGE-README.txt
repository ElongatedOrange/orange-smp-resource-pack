My resource pack

Enable the resource pack, then use these commands:

garlic_stage_2: /give @s minecraft:paper[minecraft:item_model="voxelforge:garlic_stage_2_21c42196"]

garlic_stage_1: /give @s minecraft:paper[minecraft:item_model="voxelforge:garlic_stage_1_3e5be8eb"]

garlic_stage_0: /give @s minecraft:paper[minecraft:item_model="voxelforge:garlic_stage_0_5d05bef0"]

lemon_stage_2: /give @s minecraft:paper[minecraft:item_model="voxelforge:lemon_stage_2_806e4a95"]

lemon_stage_1: /give @s minecraft:paper[minecraft:item_model="voxelforge:lemon_stage_1_eda5abf1"]

lemon_stage_0: /give @s minecraft:paper[minecraft:item_model="voxelforge:lemon_stage_0_ac59811a"]

orange_stage_2: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_stage_2_6332aa8e"]

orange_stage_1: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_stage_1_67f49152"]

orange_stage_0: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_stage_0_d5091596"]

coffee_stage_2: /give @s minecraft:paper[minecraft:item_model="voxelforge:coffee_stage_2_30fa4cea"]

coffee_stage_1: /give @s minecraft:paper[minecraft:item_model="voxelforge:coffee_stage_1_518a0057"]

coffee_stage_0: /give @s minecraft:paper[minecraft:item_model="voxelforge:coffee_stage_0_8863251d"]

soy_stage_2: /give @s minecraft:paper[minecraft:item_model="voxelforge:soy_stage_2_6df4feb3"]

soy_stage_1: /give @s minecraft:paper[minecraft:item_model="voxelforge:soy_stage_1_a52ef06c"]

soy_stage_0: /give @s minecraft:paper[minecraft:item_model="voxelforge:soy_stage_0_04ab4724"]

strawberry_stage_2: /give @s minecraft:paper[minecraft:item_model="voxelforge:strawberry_stage_2_f3aa0979"]

strawberry_stage_1: /give @s minecraft:paper[minecraft:item_model="voxelforge:strawberry_stage_1_9ccce83b"]

strawberry_stage_0: /give @s minecraft:paper[minecraft:item_model="voxelforge:strawberry_stage_0_2d0f1236"]

corn_stage_2: /give @s minecraft:paper[minecraft:item_model="voxelforge:corn_stage_2_3cfc17cc"]

corn_stage_1: /give @s minecraft:paper[minecraft:item_model="voxelforge:corn_stage_1_cb108a8d"]

corn_stage_0: /give @s minecraft:paper[minecraft:item_model="voxelforge:corn_stage_0_de777a02"]

cucumber_stage_2: /give @s minecraft:paper[minecraft:item_model="voxelforge:cucumber_stage_2_798fa999"]

cucumber_stage_1: /give @s minecraft:paper[minecraft:item_model="voxelforge:cucumber_stage_1_027b9319"]

cucumber_stage_0: /give @s minecraft:paper[minecraft:item_model="voxelforge:cucumber_stage_0_5f928f1e"]

chilli_stage_2: /give @s minecraft:paper[minecraft:item_model="voxelforge:chilli_stage_2_2c855d09"]

chilli_stage_1: /give @s minecraft:paper[minecraft:item_model="voxelforge:chilli_stage_1_43cf5158"]

chilli_stage_0: /give @s minecraft:paper[minecraft:item_model="voxelforge:chilli_stage_0_c4608c1f"]

rice_stage_2: /give @s minecraft:paper[minecraft:item_model="voxelforge:rice_stage_2_4708086b"]

rice_stage_1: /give @s minecraft:paper[minecraft:item_model="voxelforge:rice_stage_1_c167cda7"]

rice_stage_0: /give @s minecraft:paper[minecraft:item_model="voxelforge:rice_stage_0_b9de1828"]

onion_stage_2: /give @s minecraft:paper[minecraft:item_model="voxelforge:onion_stage_2_2f5dacd9"]

onion_stage_1: /give @s minecraft:paper[minecraft:item_model="voxelforge:onion_stage_1_4d21e28c"]

onion_stage_0: /give @s minecraft:paper[minecraft:item_model="voxelforge:onion_stage_0_f2045795"]

lettuce_stage_2: /give @s minecraft:paper[minecraft:item_model="voxelforge:lettuce_stage_2_758d15a6"]

lettuce_stage_1: /give @s minecraft:paper[minecraft:item_model="voxelforge:lettuce_stage_1_80e79912"]

lettuce_stage_0: /give @s minecraft:paper[minecraft:item_model="voxelforge:lettuce_stage_0_586b0c1c"]

tomato_stage_2: /give @s minecraft:paper[minecraft:item_model="voxelforge:tomato_stage_2_6c56c301"]

tomato_stage_1: /give @s minecraft:paper[minecraft:item_model="voxelforge:tomato_stage_1_988e832e"]

tomato_stage_0: /give @s minecraft:paper[minecraft:item_model="voxelforge:tomato_stage_0_f0ceb85b"]

hot_chocolate_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:hot_chocolate_silhouette_a60514ff"]

mocha_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:mocha_silhouette_3e9d797b"]

latte_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:latte_silhouette_0c3982ab"]

espresso_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:espresso_silhouette_e242a8ae"]

iced_coffee_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:iced_coffee_silhouette_c41efbbe"]

berry_smoothie_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:berry_smoothie_silhouette_e138046e"]

chocolate_milkshake_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chocolate_milkshake_silhouette_1e023e27"]

strawberry_milkshake_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:strawberry_milkshake_silhouette_ef243afe"]

lemonade_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:lemonade_silhouette_5f8607dc"]



Java target: 1.21.4 item model format (pack format 46 by default). A custom block asset is an item/display model unless a vanilla texture binding is set.