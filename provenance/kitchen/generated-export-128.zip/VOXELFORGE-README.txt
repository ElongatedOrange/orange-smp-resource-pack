My resource pack

Enable the resource pack, then use these commands:

orange_juice_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_juice_silhouette_a4f569e2"]

grilled_corn_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:grilled_corn_silhouette_1d60ca68"]

pulled_pork_sandwich_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:pulled_pork_sandwich_silhouette_ef9a55dd"]

vegetable_skewer_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:vegetable_skewer_silhouette_40ed959a"]

chicken_skewer_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chicken_skewer_silhouette_431cdeb6"]

hot_wings_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:hot_wings_silhouette_e0d6530e"]

bbq_wings_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:bbq_wings_silhouette_f4d559b0"]

smoked_brisket_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:smoked_brisket_silhouette_a550624c"]

bbq_ribs_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:bbq_ribs_silhouette_fc206b09"]

pork_bao_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:pork_bao_silhouette_4f5cac8b"]

vegetable_dumplings_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:vegetable_dumplings_silhouette_37a96b4f"]

pork_dumplings_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:pork_dumplings_silhouette_5c21af9a"]

beef_noodles_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:beef_noodles_silhouette_c0bcf36d"]

vegetable_noodles_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:vegetable_noodles_silhouette_4ff2f84d"]

chicken_fried_rice_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chicken_fried_rice_silhouette_ab9b3bbc"]

egg_fried_rice_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:egg_fried_rice_silhouette_0565e8c1"]

spicy_ramen_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:spicy_ramen_silhouette_8b2473e4"]

mushroom_ramen_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:mushroom_ramen_silhouette_862c831d"]

chicken_ramen_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chicken_ramen_silhouette_a43cf063"]

pancakes_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:pancakes_silhouette_5ffc3003"]

chocolate_cake_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chocolate_cake_silhouette_82372af6"]

strawberry_cake_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:strawberry_cake_silhouette_f6649f64"]

berry_pie_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:berry_pie_silhouette_492fbedd"]

apple_pie_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:apple_pie_silhouette_0c775fa0"]

chocolate_cookie_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chocolate_cookie_silhouette_1da86c12"]

sweet_roll_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:sweet_roll_silhouette_ad528ab1"]

strawberry_doughnut_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:strawberry_doughnut_silhouette_4b87be3f"]

chocolate_doughnut_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chocolate_doughnut_silhouette_94f5e41d"]

glazed_doughnut_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:glazed_doughnut_silhouette_2b6280e0"]

chocolate_croissant_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chocolate_croissant_silhouette_3d816a5c"]

croissant_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:croissant_silhouette_afd1c74c"]

garlic_bread_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:garlic_bread_silhouette_077c030c"]

calzone_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:calzone_silhouette_4f09941c"]

chilli_pizza_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chilli_pizza_silhouette_1a4d776f"]

bbq_chicken_pizza_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:bbq_chicken_pizza_silhouette_44f0d116"]

garden_pizza_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:garden_pizza_silhouette_115893a6"]

mushroom_pizza_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:mushroom_pizza_silhouette_e7b184a0"]

pepperoni_pizza_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:pepperoni_pizza_silhouette_7191f42e"]

margherita_pizza_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:margherita_pizza_silhouette_dfee4f99"]

sushi_platter_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:sushi_platter_silhouette_849fabe3"]

vegetable_tempura_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:vegetable_tempura_silhouette_16ff9810"]

salmon_onigiri_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:salmon_onigiri_silhouette_9bc9b301"]

onigiri_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:onigiri_silhouette_19114170"]

garden_roll_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:garden_roll_silhouette_53b12f44"]

spicy_salmon_roll_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:spicy_salmon_roll_silhouette_9036997b"]

salmon_maki_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:salmon_maki_silhouette_fda6c55a"]

cucumber_maki_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:cucumber_maki_silhouette_e7f8a1a9"]

cod_nigiri_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:cod_nigiri_silhouette_2d9c9be0"]

salmon_nigiri_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:salmon_nigiri_silhouette_c50e564c"]

fish_burger_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:fish_burger_silhouette_235c3876"]

chicken_nuggets_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chicken_nuggets_silhouette_9ca21416"]

onion_rings_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:onion_rings_silhouette_d7ffba6c"]

loaded_fries_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:loaded_fries_silhouette_fa7ef903"]

fries_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:fries_silhouette_efc88169"]

chilli_dog_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chilli_dog_silhouette_0fd17a12"]

hot_dog_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:hot_dog_silhouette_fea2dd66"]

veggie_burger_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:veggie_burger_silhouette_930e48ce"]

spicy_chicken_burger_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:spicy_chicken_burger_silhouette_ba68ac8b"]

chicken_burger_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chicken_burger_silhouette_39bbe478"]

double_burger_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:double_burger_silhouette_87534400"]

cheeseburger_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:cheeseburger_silhouette_b330948e"]

coffee_grounds_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:coffee_grounds_silhouette_45aef1bb"]

pulled_pork_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:pulled_pork_silhouette_bc86c201"]

fried_fish_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:fried_fish_silhouette_5b78f36c"]

fried_chicken_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:fried_chicken_silhouette_aaef7074"]

cooked_chicken_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:cooked_chicken_silhouette_46f283e4"]

sushi_rice_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:sushi_rice_silhouette_09116837"]

bbq_sauce_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:bbq_sauce_silhouette_bc1d9548"]

sliced_potato_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:sliced_potato_silhouette_ce6e5de6"]

pepperoni_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:pepperoni_silhouette_142f514c"]

sausage_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:sausage_silhouette_65e14a2a"]

broth_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:broth_silhouette_ed2d33a9"]

chocolate_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chocolate_silhouette_710d648e"]

cream_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:cream_silhouette_a4690177"]

soy_sauce_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:soy_sauce_silhouette_a607edfd"]

hot_sauce_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:hot_sauce_silhouette_387e9e5b"]

tomato_sauce_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:tomato_sauce_silhouette_1198d948"]

pizza_base_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:pizza_base_silhouette_fdced838"]

noodles_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:noodles_silhouette_da89e7b8"]

bun_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:bun_silhouette_44cd7f35"]

burger_patty_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:burger_patty_silhouette_08ca503f"]

raw_patty_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:raw_patty_silhouette_05132995"]

minced_beef_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:minced_beef_silhouette_8e5186c5"]

cod_slice_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:cod_slice_silhouette_829810f2"]

salmon_slice_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:salmon_slice_silhouette_9e695928"]

nori_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:nori_silhouette_75b64aba"]

cooked_rice_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:cooked_rice_silhouette_aa0e5b61"]

breadcrumbs_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:breadcrumbs_silhouette_37c94e51"]

batter_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:batter_silhouette_db63e770"]

dough_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:dough_silhouette_7f297131"]

cheese_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:cheese_silhouette_6035956f"]

butter_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:butter_silhouette_54b9ad36"]

salt_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:salt_silhouette_7e315749"]

flour_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:flour_silhouette_7f7ba1cb"]

Orange Kitchen Hot Chocolate: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_hot_chocolate_931935b1"]

Orange Kitchen Mocha: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mocha_11d6e74e"]

Orange Kitchen Latte: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_latte_662ef938"]

Orange Kitchen Espresso: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_espresso_80caeb70"]

Orange Kitchen Iced Coffee: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_iced_coffee_0139afa7"]

Orange Kitchen Berry Smoothie: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_berry_smoothie_1fd8d2c2"]

Orange Kitchen Chocolate Milkshake: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_chocolate_milkshake_22487f27"]

Orange Kitchen Strawberry Milkshake: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_strawberry_milkshake_a38cc986"]

Orange Kitchen Lemonade: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_lemonade_37fba71c"]

Orange Kitchen Orange Juice: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_orange_juice_db9cfa9a"]

Orange Kitchen Grilled Corn: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_grilled_corn_272c665e"]

Orange Kitchen Pulled Pork Sandwich: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_pulled_pork_sandwich_346ed04c"]

Orange Kitchen Vegetable Skewer: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_vegetable_skewer_58252e66"]

Orange Kitchen Chicken Skewer: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_chicken_skewer_9dc9f788"]

Orange Kitchen Hot Wings: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_hot_wings_fada9f08"]

Orange Kitchen Bbq Wings: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_bbq_wings_1ff06eff"]

Orange Kitchen Smoked Brisket: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_smoked_brisket_1a6f139d"]

Orange Kitchen Bbq Ribs: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_bbq_ribs_9aa4ad83"]

Orange Kitchen Pork Bao: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_pork_bao_1e93a462"]

Orange Kitchen Vegetable Dumplings: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_vegetable_dumplings_7ea6897e"]

Orange Kitchen Mature garlic Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_garlic_crop_ce75648a"]

Orange Kitchen Mature lemon Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_lemon_crop_3e6920ed"]

Orange Kitchen Mature orange Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_orange_crop_9f696563"]

Orange Kitchen Mature coffee Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_coffee_crop_4e351491"]

Orange Kitchen Mature soy Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_soy_crop_8c3bb70b"]

Orange Kitchen Mature strawberry Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_strawberry_cro_027ee289"]

Orange Kitchen Mature corn Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_corn_crop_8720d534"]

Orange Kitchen Mature cucumber Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_cucumber_crop_0899bb1c"]

Orange Kitchen Mature chilli Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_chilli_crop_3d9a2e50"]

Orange Kitchen Mature rice Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_rice_crop_fa23695a"]

Orange Kitchen Mature onion Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_onion_crop_157ca69b"]

Orange Kitchen Mature lettuce Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_lettuce_crop_dde8b3b7"]

Orange Kitchen Mature Tomato Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_tomato_crop_8bf0f4e3"]



Java target: 1.21.4 item model format (pack format 46 by default). A custom block asset is an item/display model unless a vanilla texture binding is set.

GUI artwork is editable. Java and Bedrock use different screen layouts: assign a matching texture path to override a vanilla screen. Bedrock also includes a reusable image panel; integrating it into a screen is a separate UI edit.