My resource pack

Enable the resource pack, then use these commands:

orange_juice_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_juice_silhouette_8a56d4d7"]

grilled_corn_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:grilled_corn_silhouette_37b12394"]

pulled_pork_sandwich_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:pulled_pork_sandwich_silhouette_c27fa8f7"]

vegetable_skewer_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:vegetable_skewer_silhouette_8191ad21"]

chicken_skewer_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chicken_skewer_silhouette_cb583873"]

hot_wings_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:hot_wings_silhouette_0ae6db6d"]

bbq_wings_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:bbq_wings_silhouette_a1a2afeb"]

smoked_brisket_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:smoked_brisket_silhouette_eb4c9344"]

bbq_ribs_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:bbq_ribs_silhouette_74380d48"]

pork_bao_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:pork_bao_silhouette_922931c1"]

vegetable_dumplings_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:vegetable_dumplings_silhouette_c5a7dc66"]

pork_dumplings_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:pork_dumplings_silhouette_0f951288"]

beef_noodles_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:beef_noodles_silhouette_9e83a291"]

vegetable_noodles_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:vegetable_noodles_silhouette_fab594fd"]

chicken_fried_rice_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chicken_fried_rice_silhouette_6047f0c6"]

egg_fried_rice_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:egg_fried_rice_silhouette_0931f112"]

spicy_ramen_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:spicy_ramen_silhouette_e78db1d9"]

mushroom_ramen_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:mushroom_ramen_silhouette_f9301264"]

chicken_ramen_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chicken_ramen_silhouette_51f0cdec"]

pancakes_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:pancakes_silhouette_398c9967"]

chocolate_cake_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chocolate_cake_silhouette_668f1d1a"]

strawberry_cake_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:strawberry_cake_silhouette_bfd9ccfe"]

berry_pie_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:berry_pie_silhouette_6a55776a"]

apple_pie_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:apple_pie_silhouette_2177706e"]

chocolate_cookie_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chocolate_cookie_silhouette_cef33bcd"]

sweet_roll_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:sweet_roll_silhouette_3d0a639d"]

strawberry_doughnut_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:strawberry_doughnut_silhouette_38048c4c"]

chocolate_doughnut_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chocolate_doughnut_silhouette_a5e61699"]

glazed_doughnut_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:glazed_doughnut_silhouette_4ea7521b"]

chocolate_croissant_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chocolate_croissant_silhouette_0c947307"]

croissant_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:croissant_silhouette_bf690317"]

garlic_bread_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:garlic_bread_silhouette_09b23d9a"]

calzone_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:calzone_silhouette_c8c6a82d"]

chilli_pizza_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chilli_pizza_silhouette_cf9fb99e"]

bbq_chicken_pizza_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:bbq_chicken_pizza_silhouette_b152e525"]

garden_pizza_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:garden_pizza_silhouette_9d10fb04"]

mushroom_pizza_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:mushroom_pizza_silhouette_807bd187"]

pepperoni_pizza_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:pepperoni_pizza_silhouette_7c909d19"]

margherita_pizza_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:margherita_pizza_silhouette_522faa21"]

sushi_platter_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:sushi_platter_silhouette_d301f8ee"]

vegetable_tempura_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:vegetable_tempura_silhouette_e7216ae8"]

salmon_onigiri_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:salmon_onigiri_silhouette_8d187bcd"]

onigiri_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:onigiri_silhouette_037a99c1"]

garden_roll_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:garden_roll_silhouette_48edfafd"]

spicy_salmon_roll_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:spicy_salmon_roll_silhouette_3e85d576"]

salmon_maki_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:salmon_maki_silhouette_1ab47ee0"]

cucumber_maki_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:cucumber_maki_silhouette_04f223de"]

cod_nigiri_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:cod_nigiri_silhouette_fb49d8f2"]

salmon_nigiri_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:salmon_nigiri_silhouette_96dd459e"]

fish_burger_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:fish_burger_silhouette_780c2588"]

chicken_nuggets_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chicken_nuggets_silhouette_951586e6"]

onion_rings_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:onion_rings_silhouette_21935bd1"]

loaded_fries_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:loaded_fries_silhouette_f3ca1158"]

fries_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:fries_silhouette_fc5803a0"]

chilli_dog_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chilli_dog_silhouette_18ed803d"]

hot_dog_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:hot_dog_silhouette_b299086c"]

veggie_burger_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:veggie_burger_silhouette_0c29bc9a"]

spicy_chicken_burger_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:spicy_chicken_burger_silhouette_a3ede412"]

chicken_burger_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chicken_burger_silhouette_ccca6ce1"]

double_burger_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:double_burger_silhouette_09bfcdac"]

cheeseburger_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:cheeseburger_silhouette_319a83f0"]

coffee_grounds_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:coffee_grounds_silhouette_cc185665"]

pulled_pork_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:pulled_pork_silhouette_918d47a7"]

fried_fish_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:fried_fish_silhouette_ad3d20dc"]

fried_chicken_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:fried_chicken_silhouette_5b22be94"]

cooked_chicken_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:cooked_chicken_silhouette_63b7942d"]

sushi_rice_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:sushi_rice_silhouette_5a3d94c6"]

bbq_sauce_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:bbq_sauce_silhouette_c7012cee"]

sliced_potato_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:sliced_potato_silhouette_9a90be06"]

pepperoni_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:pepperoni_silhouette_a8758dad"]

sausage_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:sausage_silhouette_7b1753e8"]

broth_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:broth_silhouette_56f7873a"]

chocolate_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chocolate_silhouette_b730ce96"]

cream_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:cream_silhouette_110ec1d6"]

soy_sauce_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:soy_sauce_silhouette_53bf65cd"]

hot_sauce_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:hot_sauce_silhouette_912543f9"]

tomato_sauce_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:tomato_sauce_silhouette_1e0aa1c8"]

pizza_base_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:pizza_base_silhouette_b61d1cc7"]

noodles_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:noodles_silhouette_6cc92ccb"]

bun_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:bun_silhouette_5f9ea67e"]

burger_patty_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:burger_patty_silhouette_dac0fc58"]

raw_patty_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:raw_patty_silhouette_58100b60"]

minced_beef_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:minced_beef_silhouette_8fd8e280"]

cod_slice_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:cod_slice_silhouette_f0d9f31c"]

salmon_slice_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:salmon_slice_silhouette_d97e4830"]

nori_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:nori_silhouette_fbbb077b"]

cooked_rice_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:cooked_rice_silhouette_e45694f1"]

breadcrumbs_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:breadcrumbs_silhouette_a11199bb"]

batter_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:batter_silhouette_97f5ae20"]

dough_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:dough_silhouette_d78ac006"]

cheese_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:cheese_silhouette_bffde74f"]

butter_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:butter_silhouette_035de706"]

salt_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:salt_silhouette_70bf24f1"]

flour_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:flour_silhouette_08bfcc10"]

Orange Kitchen Hot Chocolate: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_hot_chocolate_931935b1"]

Orange Kitchen Mocha: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mocha_11d6e74e"]

Orange Kitchen Latte: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_latte_662ef938"]

Orange Kitchen Espresso: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_espresso_80caeb70"]

Orange Kitchen Iced Coffee: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_iced_coffee_0139afa7"]

Orange Kitchen Berry Smoothie: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_berry_smoothie_1fd8d2c2"]

Orange Kitchen Chocolate Milkshake: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_chocolate_milkshake_22487f27"]

Orange Kitchen Strawberry Milkshake: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_strawberry_milkshake_a38cc986"]

Orange Kitchen Lemonade: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_lemonade_37fba71c"]

Orange Kitchen Orange Juice: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_orange_juice_db9cfa9a"]

Orange Kitchen Grilled Corn: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_grilled_corn_272c665e"]

Orange Kitchen Pulled Pork Sandwich: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_pulled_pork_sandwich_346ed04c"]

Orange Kitchen Vegetable Skewer: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_vegetable_skewer_58252e66"]

Orange Kitchen Chicken Skewer: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_chicken_skewer_9dc9f788"]

Orange Kitchen Hot Wings: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_hot_wings_fada9f08"]

Orange Kitchen Bbq Wings: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_bbq_wings_1ff06eff"]

Orange Kitchen Smoked Brisket: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_smoked_brisket_1a6f139d"]

Orange Kitchen Bbq Ribs: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_bbq_ribs_9aa4ad83"]

Orange Kitchen Pork Bao: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_pork_bao_1e93a462"]

Orange Kitchen Vegetable Dumplings: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_vegetable_dumplings_7ea6897e"]

Orange Kitchen Mature garlic Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_garlic_crop_ce75648a"]

Orange Kitchen Mature lemon Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_lemon_crop_3e6920ed"]

Orange Kitchen Mature orange Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_orange_crop_9f696563"]

Orange Kitchen Mature coffee Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_coffee_crop_4e351491"]

Orange Kitchen Mature soy Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_soy_crop_8c3bb70b"]

Orange Kitchen Mature strawberry Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_strawberry_cro_027ee289"]

Orange Kitchen Mature corn Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_corn_crop_8720d534"]

Orange Kitchen Mature cucumber Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_cucumber_crop_0899bb1c"]

Orange Kitchen Mature chilli Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_chilli_crop_3d9a2e50"]

Orange Kitchen Mature rice Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_rice_crop_fa23695a"]

Orange Kitchen Mature onion Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_onion_crop_157ca69b"]

Orange Kitchen Mature lettuce Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_lettuce_crop_dde8b3b7"]

Orange Kitchen Mature Tomato Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_tomato_crop_8bf0f4e3"]



Java target: 1.21.4 item model format (pack format 46 by default). A custom block asset is an item/display model unless a vanilla texture binding is set.

GUI artwork is editable. Java and Bedrock use different screen layouts: assign a matching texture path to override a vanilla screen. Bedrock also includes a reusable image panel; integrating it into a screen is a separate UI edit.