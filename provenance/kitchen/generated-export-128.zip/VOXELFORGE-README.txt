My resource pack

Enable the resource pack, then use these commands:

orange_juice_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_juice_silhouette_f3df328b"]

grilled_corn_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:grilled_corn_silhouette_332d20db"]

pulled_pork_sandwich_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:pulled_pork_sandwich_silhouette_eb8e9b9c"]

vegetable_skewer_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:vegetable_skewer_silhouette_a5020b2e"]

chicken_skewer_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chicken_skewer_silhouette_1f5b96f7"]

hot_wings_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:hot_wings_silhouette_035b7fd1"]

bbq_wings_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:bbq_wings_silhouette_ff9e17d6"]

smoked_brisket_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:smoked_brisket_silhouette_5d0ce4a8"]

bbq_ribs_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:bbq_ribs_silhouette_2f250921"]

pork_bao_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:pork_bao_silhouette_8627f8a0"]

vegetable_dumplings_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:vegetable_dumplings_silhouette_a953ea05"]

pork_dumplings_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:pork_dumplings_silhouette_86496c77"]

beef_noodles_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:beef_noodles_silhouette_c3b43b88"]

vegetable_noodles_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:vegetable_noodles_silhouette_4f34bfba"]

chicken_fried_rice_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chicken_fried_rice_silhouette_ef685c79"]

egg_fried_rice_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:egg_fried_rice_silhouette_2178a267"]

spicy_ramen_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:spicy_ramen_silhouette_4ebdbf7a"]

mushroom_ramen_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:mushroom_ramen_silhouette_ee6d2d2a"]

chicken_ramen_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chicken_ramen_silhouette_f4efc36e"]

pancakes_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:pancakes_silhouette_1e14895b"]

chocolate_cake_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chocolate_cake_silhouette_18d5c74f"]

strawberry_cake_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:strawberry_cake_silhouette_de3ca623"]

berry_pie_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:berry_pie_silhouette_1c6d3166"]

apple_pie_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:apple_pie_silhouette_ad28a058"]

chocolate_cookie_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chocolate_cookie_silhouette_83924dd4"]

sweet_roll_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:sweet_roll_silhouette_e8405f4a"]

strawberry_doughnut_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:strawberry_doughnut_silhouette_5316da0c"]

chocolate_doughnut_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chocolate_doughnut_silhouette_8d5f8cc0"]

glazed_doughnut_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:glazed_doughnut_silhouette_31ecd7ac"]

chocolate_croissant_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chocolate_croissant_silhouette_fbd75c8c"]

croissant_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:croissant_silhouette_2f5420e1"]

garlic_bread_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:garlic_bread_silhouette_03610c61"]

calzone_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:calzone_silhouette_298f7ade"]

chilli_pizza_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chilli_pizza_silhouette_700a18dd"]

bbq_chicken_pizza_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:bbq_chicken_pizza_silhouette_f586ef92"]

garden_pizza_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:garden_pizza_silhouette_dcc114b4"]

mushroom_pizza_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:mushroom_pizza_silhouette_48d16aed"]

pepperoni_pizza_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:pepperoni_pizza_silhouette_6415ee99"]

margherita_pizza_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:margherita_pizza_silhouette_deb38479"]

sushi_platter_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:sushi_platter_silhouette_9fc95ecf"]

vegetable_tempura_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:vegetable_tempura_silhouette_ae5af459"]

salmon_onigiri_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:salmon_onigiri_silhouette_31f8a020"]

onigiri_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:onigiri_silhouette_2550c524"]

garden_roll_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:garden_roll_silhouette_7555d7ea"]

spicy_salmon_roll_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:spicy_salmon_roll_silhouette_2dd5477c"]

salmon_maki_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:salmon_maki_silhouette_177f4abd"]

cucumber_maki_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:cucumber_maki_silhouette_bf98145c"]

cod_nigiri_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:cod_nigiri_silhouette_c12b3d0a"]

salmon_nigiri_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:salmon_nigiri_silhouette_8277f1ab"]

fish_burger_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:fish_burger_silhouette_92289a05"]

chicken_nuggets_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chicken_nuggets_silhouette_8df9d7c1"]

onion_rings_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:onion_rings_silhouette_28cd9f71"]

loaded_fries_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:loaded_fries_silhouette_a1ea8b55"]

fries_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:fries_silhouette_7c2db1bd"]

chilli_dog_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chilli_dog_silhouette_6549c14c"]

hot_dog_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:hot_dog_silhouette_387fa06c"]

veggie_burger_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:veggie_burger_silhouette_41bea6db"]

spicy_chicken_burger_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:spicy_chicken_burger_silhouette_142d79e5"]

chicken_burger_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chicken_burger_silhouette_e535c12e"]

double_burger_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:double_burger_silhouette_9edbfdc4"]

cheeseburger_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:cheeseburger_silhouette_dc44edb6"]

coffee_grounds_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:coffee_grounds_silhouette_5391ad15"]

pulled_pork_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:pulled_pork_silhouette_c67d3fb0"]

fried_fish_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:fried_fish_silhouette_dc939cd6"]

fried_chicken_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:fried_chicken_silhouette_75be30e7"]

cooked_chicken_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:cooked_chicken_silhouette_39d0bd47"]

sushi_rice_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:sushi_rice_silhouette_3c927de7"]

bbq_sauce_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:bbq_sauce_silhouette_a1ba03d1"]

sliced_potato_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:sliced_potato_silhouette_a1a1f8ef"]

pepperoni_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:pepperoni_silhouette_2b335ab9"]

sausage_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:sausage_silhouette_58b1331f"]

broth_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:broth_silhouette_8d0fff1f"]

chocolate_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:chocolate_silhouette_1c56e721"]

cream_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:cream_silhouette_48c8148f"]

soy_sauce_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:soy_sauce_silhouette_16b3cf11"]

hot_sauce_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:hot_sauce_silhouette_63a19482"]

tomato_sauce_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:tomato_sauce_silhouette_faa53062"]

pizza_base_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:pizza_base_silhouette_e312f9f4"]

noodles_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:noodles_silhouette_d5e4bdae"]

bun_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:bun_silhouette_1737a20d"]

burger_patty_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:burger_patty_silhouette_064e68e5"]

raw_patty_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:raw_patty_silhouette_30f9f74e"]

minced_beef_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:minced_beef_silhouette_ff729554"]

cod_slice_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:cod_slice_silhouette_7794dc35"]

salmon_slice_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:salmon_slice_silhouette_30c3595b"]

nori_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:nori_silhouette_4eed96c8"]

cooked_rice_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:cooked_rice_silhouette_a8e4ed65"]

breadcrumbs_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:breadcrumbs_silhouette_46fc9636"]

batter_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:batter_silhouette_05f01b94"]

dough_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:dough_silhouette_85780cef"]

cheese_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:cheese_silhouette_ec27706b"]

butter_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:butter_silhouette_2aa89bda"]

salt_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:salt_silhouette_56b72e17"]

flour_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:flour_silhouette_4a3d26e6"]

Orange Kitchen Mature garlic Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_garlic_crop_ce75648a"]

Orange Kitchen Mature lemon Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_lemon_crop_3e6920ed"]

Orange Kitchen Mature orange Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_orange_crop_9f696563"]

Orange Kitchen Mature coffee Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_coffee_crop_4e351491"]

Orange Kitchen Mature soy Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_soy_crop_8c3bb70b"]

Orange Kitchen Mature strawberry Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_strawberry_cro_027ee289"]

Orange Kitchen Mature corn Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_corn_crop_8720d534"]

Orange Kitchen Mature cucumber Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_cucumber_crop_0899bb1c"]

Orange Kitchen Mature chilli Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_chilli_crop_3d9a2e50"]

Orange Kitchen Mature rice Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_rice_crop_fa23695a"]

Orange Kitchen Mature onion Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_onion_crop_157ca69b"]

Orange Kitchen Mature lettuce Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_lettuce_crop_dde8b3b7"]

Orange Kitchen Mature Tomato Crop: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mature_tomato_crop_8bf0f4e3"]

Orange Kitchen Hot Chocolate: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_hot_chocolate_931935b1"]

Orange Kitchen Mocha: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_mocha_11d6e74e"]

Orange Kitchen Latte: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_latte_662ef938"]

Orange Kitchen Espresso: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_espresso_80caeb70"]

Orange Kitchen Iced Coffee: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_iced_coffee_0139afa7"]

Orange Kitchen Berry Smoothie: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_berry_smoothie_1fd8d2c2"]

Orange Kitchen Chocolate Milkshake: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_chocolate_milkshake_22487f27"]

Orange Kitchen Strawberry Milkshake: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_strawberry_milkshake_a38cc986"]

Orange Kitchen Lemonade: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_lemonade_37fba71c"]

Orange Kitchen Orange Juice: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_orange_juice_db9cfa9a"]

Orange Kitchen Grilled Corn: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_grilled_corn_272c665e"]

Orange Kitchen Pulled Pork Sandwich: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_pulled_pork_sandwich_346ed04c"]

Orange Kitchen Vegetable Skewer: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_vegetable_skewer_58252e66"]

Orange Kitchen Chicken Skewer: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_chicken_skewer_9dc9f788"]

Orange Kitchen Hot Wings: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_hot_wings_fada9f08"]

Orange Kitchen Bbq Wings: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_bbq_wings_1ff06eff"]

Orange Kitchen Smoked Brisket: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_smoked_brisket_1a6f139d"]

Orange Kitchen Bbq Ribs: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_bbq_ribs_9aa4ad83"]

Orange Kitchen Pork Bao: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_pork_bao_1e93a462"]

Orange Kitchen Vegetable Dumplings: /give @s minecraft:paper[minecraft:item_model="voxelforge:orange_kitchen_vegetable_dumplings_7ea6897e"]



Java target: 1.21.4 item model format (pack format 46 by default). A custom block asset is an item/display model unless a vanilla texture binding is set.

GUI artwork is editable. Java and Bedrock use different screen layouts: assign a matching texture path to override a vanilla screen. Bedrock also includes a reusable image panel; integrating it into a screen is a separate UI edit.