My resource pack

Enable the resource pack, then use these commands:

Kitchen HUD icon_pulled_pork_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_pulled_pork_large_f2f4cc7e"]

Kitchen HUD icon_pulled_pork: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_pulled_pork_14481bf9"]

Kitchen HUD icon_fried_fish_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_fried_fish_large_5c824371"]

Kitchen HUD icon_fried_fish: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_fried_fish_7a7e4486"]

Kitchen HUD icon_fried_chicken_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_fried_chicken_large_c09e82cc"]

Kitchen HUD icon_fried_chicken: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_fried_chicken_5a699a24"]

Kitchen HUD icon_cooked_chicken_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cooked_chicken_larg_85c8197e"]

Kitchen HUD icon_cooked_chicken: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cooked_chicken_4ea1983d"]

Kitchen HUD icon_sushi_rice_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_sushi_rice_large_ef47f9e1"]

Kitchen HUD icon_sushi_rice: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_sushi_rice_20e59a51"]

Kitchen HUD icon_bbq_sauce_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_bbq_sauce_large_8fc3258f"]

Kitchen HUD icon_bbq_sauce: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_bbq_sauce_9873e9e8"]

Kitchen HUD icon_sliced_potato_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_sliced_potato_large_5ab7a2a2"]

Kitchen HUD icon_sliced_potato: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_sliced_potato_3d2e3d55"]

Kitchen HUD icon_pepperoni_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_pepperoni_large_700723f7"]

Kitchen HUD icon_pepperoni: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_pepperoni_482efa63"]

Kitchen HUD icon_sausage_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_sausage_large_97f6e865"]

Kitchen HUD icon_sausage: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_sausage_9a2c58ff"]

Kitchen HUD icon_broth_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_broth_large_ab0adc14"]

Kitchen HUD icon_broth: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_broth_cdb0d0d2"]

Kitchen HUD icon_chocolate_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chocolate_large_7c11aa29"]

Kitchen HUD icon_chocolate: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chocolate_8c47a3f7"]

Kitchen HUD icon_cream_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cream_large_abbfcc14"]

Kitchen HUD icon_cream: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cream_f780220c"]

Kitchen HUD icon_soy_sauce_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_soy_sauce_large_8fc421d0"]

Kitchen HUD icon_soy_sauce: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_soy_sauce_b23e3d7d"]

Kitchen HUD icon_hot_sauce_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_hot_sauce_large_d9263138"]

Kitchen HUD icon_hot_sauce: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_hot_sauce_d9e3a776"]

Kitchen HUD icon_tomato_sauce_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_tomato_sauce_large_d16d59f6"]

Kitchen HUD icon_tomato_sauce: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_tomato_sauce_2000ae7a"]

Kitchen HUD icon_pizza_base_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_pizza_base_large_4a623411"]

Kitchen HUD icon_pizza_base: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_pizza_base_7feae746"]

Kitchen HUD icon_noodles_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_noodles_large_731f44b8"]

Kitchen HUD icon_noodles: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_noodles_317ec910"]

Kitchen HUD icon_bun_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_bun_large_980ea162"]

Kitchen HUD icon_bun: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_bun_ece7a190"]

Kitchen HUD icon_burger_patty_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_burger_patty_large_e5bccabd"]

Kitchen HUD icon_burger_patty: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_burger_patty_faaef0da"]

Kitchen HUD icon_raw_patty_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_raw_patty_large_44dbea1f"]

Kitchen HUD icon_raw_patty: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_raw_patty_38830513"]

Kitchen HUD icon_minced_beef_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minced_beef_large_713dff1b"]

Kitchen HUD icon_minced_beef: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minced_beef_596217f6"]

Kitchen HUD icon_cod_slice_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cod_slice_large_66022762"]

Kitchen HUD icon_cod_slice: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cod_slice_2e68e222"]

Kitchen HUD icon_salmon_slice_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_salmon_slice_large_fc6b06fa"]

Kitchen HUD icon_salmon_slice: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_salmon_slice_e28a19e1"]

Kitchen HUD icon_cooked_rice_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cooked_rice_large_77dbd900"]

Kitchen HUD icon_cooked_rice: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cooked_rice_0d676f2b"]

Kitchen HUD icon_breadcrumbs_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_breadcrumbs_large_e595d29d"]

Kitchen HUD icon_breadcrumbs: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_breadcrumbs_25f41caa"]

Kitchen HUD icon_batter_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_batter_large_d88f7f46"]

Kitchen HUD icon_batter: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_batter_14612570"]

Kitchen HUD icon_dough_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_dough_large_2e3ba2e9"]

Kitchen HUD icon_dough: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_dough_dd42563f"]

Kitchen HUD icon_cheese_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cheese_large_b735186a"]

Kitchen HUD icon_cheese: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cheese_8bed10ed"]

Kitchen HUD icon_butter_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_butter_large_26da083a"]

Kitchen HUD icon_butter: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_butter_7ec5f299"]

Kitchen HUD icon_garlic_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_garlic_large_d12c052c"]

Kitchen HUD icon_garlic: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_garlic_ade31c63"]

Kitchen HUD icon_lemon_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_lemon_large_9316de96"]

Kitchen HUD icon_lemon: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_lemon_b260326f"]

Kitchen HUD icon_orange_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_orange_large_44636bc0"]

Kitchen HUD icon_orange: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_orange_efb7f181"]

Kitchen HUD icon_coffee_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_coffee_large_ed5ae694"]

Kitchen HUD icon_coffee: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_coffee_1fb9692c"]

Kitchen HUD icon_soy_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_soy_large_d5e5e0d1"]

Kitchen HUD icon_soy: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_soy_dbd58ed1"]

Kitchen HUD icon_strawberry_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_strawberry_large_1f5b6ac8"]

Kitchen HUD icon_strawberry: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_strawberry_a360e577"]

Kitchen HUD icon_corn_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_corn_large_2ccb32f7"]

Kitchen HUD icon_corn: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_corn_ddc96a70"]

Kitchen HUD icon_cucumber_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cucumber_large_96369152"]

Kitchen HUD icon_cucumber: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cucumber_d06dddd9"]

Kitchen HUD icon_chilli_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chilli_large_3ed4458d"]

Kitchen HUD icon_coffee_grounds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_coffee_grounds_e5c5a6c1"]

Kitchen HUD icon_nori_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_nori_large_2ecfd244"]

Kitchen HUD icon_nori: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_nori_0bef7036"]

Kitchen HUD icon_salt_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_salt_large_f208f216"]

Kitchen HUD icon_salt: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_salt_2239fb65"]

Kitchen HUD icon_flour_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_flour_large_c1bd31cc"]

Kitchen HUD icon_flour: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_flour_a0cd476d"]

Kitchen HUD icon_garlic_seeds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_garlic_seeds_large_00a8bb17"]

Kitchen HUD icon_garlic_seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_garlic_seeds_86075147"]

Kitchen HUD icon_lemon_seeds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_lemon_seeds_large_20066dc1"]

Kitchen HUD icon_lemon_seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_lemon_seeds_41c5956b"]

Kitchen HUD icon_orange_seeds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_orange_seeds_large_a2f9e1c4"]

Kitchen HUD icon_orange_seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_orange_seeds_6f78f9f3"]

Kitchen HUD icon_coffee_seeds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_coffee_seeds_large_362ef95f"]

Kitchen HUD icon_coffee_seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_coffee_seeds_77e2e693"]

Kitchen HUD icon_soy_seeds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_soy_seeds_large_a126e60f"]

Kitchen HUD icon_soy_seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_soy_seeds_7d97fe19"]

Kitchen HUD icon_strawberry_seeds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_strawberry_seeds_la_3faebb8c"]

Kitchen HUD icon_strawberry_seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_strawberry_seeds_6b067dc5"]

Kitchen HUD icon_corn_seeds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_corn_seeds_large_70dbe266"]

Kitchen HUD icon_corn_seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_corn_seeds_e442df15"]

Kitchen HUD icon_cucumber_seeds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cucumber_seeds_larg_4d2b96bd"]

Kitchen HUD icon_cucumber_seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cucumber_seeds_473a7db9"]

Kitchen HUD icon_chilli_seeds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chilli_seeds_large_605e57f8"]

Kitchen HUD icon_chilli_seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chilli_seeds_3642235e"]



Java target: 1.21.4 item model format (pack format 46 by default). A custom block asset is an item/display model unless a vanilla texture binding is set.