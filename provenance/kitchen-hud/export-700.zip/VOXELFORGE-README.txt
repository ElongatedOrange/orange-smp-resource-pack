My resource pack

Enable the resource pack, then use these commands:

Kitchen HUD icon_minecraft_wheat_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_wheat_lar_7bebdc68"]

Kitchen HUD icon_minecraft_wheat: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_wheat_6ea8a8eb"]

Kitchen HUD icon_minecraft_water_bottle_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_water_bot_4fd68135"]

Kitchen HUD icon_minecraft_water_bottle: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_water_bot_2caa801c"]

Kitchen HUD icon_minecraft_sweet_berries_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_sweet_ber_132ecf5c"]

Kitchen HUD icon_minecraft_sweet_berries: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_sweet_ber_a1673c9f"]

Kitchen HUD icon_minecraft_sugar_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_sugar_lar_c4d8cca3"]

Kitchen HUD icon_minecraft_sugar: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_sugar_94918463"]

Kitchen HUD icon_minecraft_salmon_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_salmon_la_c05a056e"]

Kitchen HUD icon_minecraft_salmon: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_salmon_199823e3"]

Kitchen HUD icon_minecraft_potato_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_potato_la_54cda51e"]



Java target: 1.21.4 item model format (pack format 46 by default). A custom block asset is an item/display model unless a vanilla texture binding is set.