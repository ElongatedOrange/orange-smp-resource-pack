My resource pack

Enable the resource pack, then use these commands:

Kitchen HUD icon_hot_chocolate_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_hot_chocolate_silho_432d8050"]

Kitchen HUD icon_hot_chocolate_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_hot_chocolate_silho_1d36b661"]

Kitchen HUD icon_mocha_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_mocha_silhouette_la_7b2bf7e7"]

Kitchen HUD icon_mocha_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_mocha_silhouette_b600a1c4"]

Kitchen HUD icon_latte_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_latte_silhouette_la_5074f1ed"]

Kitchen HUD icon_latte_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_latte_silhouette_2bba37ed"]

Kitchen HUD icon_espresso_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_espresso_silhouette_c9476fd6"]

Kitchen HUD icon_espresso_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_espresso_silhouette_380c4c27"]

Kitchen HUD icon_iced_coffee_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_iced_coffee_silhoue_ababc2b0"]

Kitchen HUD icon_iced_coffee_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_iced_coffee_silhoue_6b2e86b2"]

Kitchen HUD icon_berry_smoothie_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_berry_smoothie_silh_39040efd"]

Kitchen HUD icon_berry_smoothie_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_berry_smoothie_silh_0d2ebcd3"]

Kitchen HUD icon_chocolate_milkshake_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chocolate_milkshake_db63bfc2"]

Kitchen HUD icon_chocolate_milkshake_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chocolate_milkshake_2755234a"]

Kitchen HUD icon_strawberry_milkshake_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_strawberry_milkshak_b0217996"]

Kitchen HUD icon_strawberry_milkshake_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_strawberry_milkshak_57a2edcd"]

Kitchen HUD icon_lemonade_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_lemonade_silhouette_f91346dd"]

Kitchen HUD icon_lemonade_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_lemonade_silhouette_401a42bc"]

Kitchen HUD icon_orange_juice_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_orange_juice_silhou_7dff7915"]

Kitchen HUD icon_orange_juice_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_orange_juice_silhou_03353f7c"]

Kitchen HUD icon_grilled_corn_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_grilled_corn_silhou_e65009a5"]

Kitchen HUD icon_grilled_corn_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_grilled_corn_silhou_768f49d5"]

Kitchen HUD icon_pulled_pork_sandwich_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_pulled_pork_sandwic_7431ef03"]

Kitchen HUD icon_pulled_pork_sandwich_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_pulled_pork_sandwic_0c658e8e"]

Kitchen HUD icon_vegetable_skewer_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_vegetable_skewer_si_db1b3b08"]

Kitchen HUD icon_vegetable_skewer_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_vegetable_skewer_si_fc3195b7"]

Kitchen HUD icon_minecraft_wheat_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_wheat_lar_7bebdc68"]

Kitchen HUD icon_minecraft_wheat: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_wheat_6ea8a8eb"]

Kitchen HUD icon_minecraft_water_bottle_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_water_bot_4fd68135"]

Kitchen HUD icon_minecraft_water_bottle: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_water_bot_2caa801c"]

Kitchen HUD icon_minecraft_sweet_berries_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_sweet_ber_132ecf5c"]

Kitchen HUD icon_minecraft_sweet_berries: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_sweet_ber_a1673c9f"]

Kitchen HUD icon_minecraft_sugar_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_sugar_lar_c4d8cca3"]

Kitchen HUD icon_minecraft_sugar: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_sugar_94918463"]

Kitchen HUD icon_minecraft_salmon_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_salmon_la_c05a056e"]

Kitchen HUD icon_minecraft_salmon: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_salmon_199823e3"]

Kitchen HUD icon_minecraft_potato_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_potato_la_54cda51e"]

Kitchen HUD icon_minecraft_potato: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_potato_5bcd6435"]

Kitchen HUD icon_minecraft_porkchop_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_porkchop__5941d669"]

Kitchen HUD icon_minecraft_porkchop: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_porkchop_aff6d01f"]

Kitchen HUD icon_minecraft_milk_bucket_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_milk_buck_61641617"]

Kitchen HUD icon_minecraft_milk_bucket: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_milk_buck_b5dd30a9"]

Kitchen HUD icon_minecraft_knowledge_book_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_knowledge_1b2c79f1"]

Kitchen HUD icon_minecraft_knowledge_book: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_knowledge_d08d4237"]

Kitchen HUD icon_minecraft_ice_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_ice_large_1080f341"]

Kitchen HUD icon_minecraft_ice: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_ice_671a2596"]

Kitchen HUD icon_minecraft_honey_bottle_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_honey_bot_1906b7ec"]

Kitchen HUD icon_minecraft_honey_bottle: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_honey_bot_cc9f19d2"]

Kitchen HUD icon_minecraft_glass_bottle_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_glass_bot_e18de873"]

Kitchen HUD icon_minecraft_glass_bottle: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_glass_bot_d445d176"]

Kitchen HUD icon_minecraft_flint_and_steel_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_flint_and_16a1464b"]

Kitchen HUD icon_minecraft_flint_and_steel: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_flint_and_64e49840"]

Kitchen HUD icon_minecraft_fire_charge_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_fire_char_911fd424"]

Kitchen HUD icon_minecraft_fire_charge: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_fire_char_d5406ffe"]

Kitchen HUD icon_minecraft_feather_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_feather_l_d5a11252"]

Kitchen HUD icon_minecraft_feather: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_feather_ec834f25"]

Kitchen HUD icon_minecraft_egg_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_egg_large_5947d8f8"]

Kitchen HUD icon_minecraft_egg: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_egg_c20b178b"]

Kitchen HUD icon_minecraft_dried_kelp_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_dried_kel_155afd28"]

Kitchen HUD icon_minecraft_dried_kelp: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_dried_kel_96fd9abe"]

Kitchen HUD icon_minecraft_cod_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_cod_large_5102ddf2"]

Kitchen HUD icon_minecraft_cod: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_cod_b9056cdd"]

Kitchen HUD icon_minecraft_cocoa_beans_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_cocoa_bea_a46b9896"]

Kitchen HUD icon_minecraft_cocoa_beans: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_cocoa_bea_575edc68"]

Kitchen HUD icon_minecraft_coal_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_coal_larg_6fb6c5e9"]

Kitchen HUD icon_minecraft_coal: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_coal_43a9734c"]

Kitchen HUD icon_minecraft_clock_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_clock_lar_659f42e1"]

Kitchen HUD icon_minecraft_clock: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_clock_ca6723b3"]

Kitchen HUD icon_minecraft_chicken_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_chicken_l_2919e63a"]

Kitchen HUD icon_minecraft_chicken: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_chicken_8b687c35"]

Kitchen HUD icon_minecraft_bundle_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_bundle_la_bf064aee"]

Kitchen HUD icon_minecraft_bundle: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_bundle_a44e8f56"]

Kitchen HUD icon_minecraft_bucket_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_bucket_la_f0421488"]

Kitchen HUD icon_minecraft_bucket: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_bucket_d02ccc21"]

Kitchen HUD icon_minecraft_brown_mushroom_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_brown_mus_e0efc88a"]

Kitchen HUD icon_minecraft_brown_mushroom: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_brown_mus_b87312e4"]

Kitchen HUD icon_minecraft_bread_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_bread_lar_d47d0738"]

Kitchen HUD icon_minecraft_bread: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_bread_5e49b9c0"]

Kitchen HUD icon_minecraft_bowl_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_bowl_larg_f038ef05"]

Kitchen HUD icon_minecraft_bowl: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_bowl_d31b32c3"]

Kitchen HUD icon_minecraft_blaze_powder_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_blaze_pow_20aeee01"]

Kitchen HUD icon_minecraft_blaze_powder: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_blaze_pow_fdaf1409"]

Kitchen HUD icon_minecraft_beef_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_beef_larg_81abe6f7"]

Kitchen HUD icon_minecraft_beef: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_beef_2af59bcf"]

Kitchen HUD icon_minecraft_barrier_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_barrier_l_82c18196"]

Kitchen HUD icon_minecraft_barrier: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_barrier_b242035f"]

Kitchen HUD icon_minecraft_arrow_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_arrow_lar_b1bf3c37"]

Kitchen HUD icon_minecraft_arrow: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_arrow_93dc2935"]

Kitchen HUD icon_minecraft_apple_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_apple_lar_0f0f7005"]

Kitchen HUD icon_minecraft_apple: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minecraft_apple_f4c101e9"]



Java target: 1.21.4 item model format (pack format 46 by default). A custom block asset is an item/display model unless a vanilla texture binding is set.