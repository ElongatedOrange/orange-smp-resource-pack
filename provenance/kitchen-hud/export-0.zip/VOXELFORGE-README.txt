My resource pack

Enable the resource pack, then use these commands:

Kitchen HUD letter_102: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_102_ef6fe793"]

Kitchen HUD letter_101: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_101_29289674"]

Kitchen HUD letter_100: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_100_85db47d4"]

Kitchen HUD letter_99: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_99_9972e916"]

Kitchen HUD letter_98: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_98_8855c7ec"]

Kitchen HUD letter_97: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_97_bac56652"]

Kitchen HUD letter_96: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_96_fb6ca1d3"]

Kitchen HUD letter_95: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_95_874aec4d"]

Kitchen HUD letter_94: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_94_3cb6db79"]

Kitchen HUD letter_93: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_93_0929a34b"]

Kitchen HUD letter_92: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_92_fa85c379"]

Kitchen HUD letter_91: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_91_0cbbd895"]

Kitchen HUD letter_90: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_90_623e4a87"]

Kitchen HUD letter_89: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_89_c5110f19"]

Kitchen HUD letter_88: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_88_34f2db9d"]

Kitchen HUD letter_87: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_87_ff0de090"]

Kitchen HUD letter_86: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_86_d085969d"]

Kitchen HUD letter_85: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_85_fd6f4fa7"]

Kitchen HUD letter_84: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_84_fe0333b5"]

Kitchen HUD letter_83: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_83_920b5d37"]

Kitchen HUD letter_82: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_82_219a7240"]

Kitchen HUD letter_81: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_81_3593d309"]

Kitchen HUD letter_80: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_80_735087d3"]

Kitchen HUD letter_79: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_79_b0c0e2d2"]

Kitchen HUD letter_78: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_78_e01107f8"]

Kitchen HUD letter_77: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_77_87ef61df"]

Kitchen HUD letter_76: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_76_ca34c4ff"]

Kitchen HUD letter_75: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_75_e5de37e4"]

Kitchen HUD letter_74: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_74_834d1f7e"]

Kitchen HUD letter_73: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_73_ccbf23c7"]

Kitchen HUD letter_72: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_72_c1662b5b"]

Kitchen HUD letter_71: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_71_8a3a0492"]

Kitchen HUD letter_70: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_70_085966a9"]

Kitchen HUD letter_69: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_69_d4581ceb"]

Kitchen HUD letter_68: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_68_eb8575c9"]

Kitchen HUD letter_67: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_67_105144eb"]

Kitchen HUD letter_66: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_66_84979d2f"]

Kitchen HUD letter_65: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_65_f8a5c0bd"]

Kitchen HUD letter_64: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_64_0fa1f302"]

Kitchen HUD letter_63: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_63_6c5f3270"]

Kitchen HUD letter_62: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_62_785457bd"]

Kitchen HUD letter_61: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_61_e28eeda3"]

Kitchen HUD letter_60: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_60_e09e0a6f"]

Kitchen HUD letter_59: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_59_e30a9568"]

Kitchen HUD letter_58: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_58_5f0b25ea"]

Kitchen HUD letter_57: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_57_7965c419"]

Kitchen HUD letter_56: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_56_cdf6da67"]

Kitchen HUD letter_55: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_55_d76b09a6"]

Kitchen HUD letter_54: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_54_59849a93"]

Kitchen HUD letter_53: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_53_949b3e6a"]

Kitchen HUD letter_52: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_52_5665b284"]

Kitchen HUD letter_51: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_51_a3046943"]

Kitchen HUD letter_50: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_50_a8ce8c34"]

Kitchen HUD letter_49: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_49_6d6f63ac"]

Kitchen HUD letter_48: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_48_c1bb4819"]

Kitchen HUD letter_47: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_47_c2d730fd"]

Kitchen HUD letter_46: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_46_0d20d85b"]

Kitchen HUD letter_45: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_45_1351433b"]

Kitchen HUD letter_44: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_44_54ac6e71"]

Kitchen HUD letter_43: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_43_f9340493"]

Kitchen HUD letter_42: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_42_0f199547"]

Kitchen HUD letter_41: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_41_21988722"]

Kitchen HUD letter_40: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_40_d6cdbfe2"]

Kitchen HUD letter_39: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_39_82cd511d"]

Kitchen HUD letter_38: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_38_1f6149f5"]

Kitchen HUD letter_37: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_37_a4351c34"]

Kitchen HUD letter_36: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_36_73efe1d7"]

Kitchen HUD letter_35: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_35_f602fc83"]

Kitchen HUD letter_34: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_34_dd5e0c9f"]

Kitchen HUD letter_33: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_33_13bf9d5b"]

Kitchen HUD frame: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_frame_d5d8963a"]

Kitchen HUD path: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_path_a13f82f3"]

Kitchen HUD basket: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_basket_9cd434b6"]

Kitchen HUD success: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_success_bedc4cb9"]

Kitchen HUD needle: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_needle_dbc5b730"]

Kitchen HUD target: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_target_373da769"]

Kitchen HUD green: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_green_7344377a"]

Kitchen HUD meter: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_meter_898075a9"]

Kitchen HUD hover_button: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_hover_button_54f31e6d"]

Kitchen HUD button: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_button_08634ed9"]

Kitchen HUD board: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_board_a699fc80"]

Kitchen HUD hover_card: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_hover_card_eed9e26f"]

Kitchen HUD card: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_card_faec3f1f"]

Kitchen HUD tool_15: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_15_c38d7f27"]

Kitchen HUD tool_14: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_14_1d979924"]

Kitchen HUD tool_13: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_13_36632afb"]

Kitchen HUD tool_12: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_12_ed351388"]

Kitchen HUD tool_11: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_11_a06127cb"]

Kitchen HUD tool_10: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_10_35312bf7"]

Kitchen HUD tool_9: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_9_8b9c9fa3"]

Kitchen HUD tool_8: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_8_49bbb206"]

Kitchen HUD tool_7: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_7_c09b8d78"]

Kitchen HUD tool_6: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_6_699acf2e"]

Kitchen HUD tool_5: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_5_40b1a092"]

Kitchen HUD tool_4: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_4_b4f3cc0e"]

Kitchen HUD tool_3: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_3_a7b25d62"]

Kitchen HUD tool_2: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_2_3d5c8a48"]

Kitchen HUD tool_1: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_1_b8f7cdc2"]

Kitchen HUD tool_0: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_0_1303e1a8"]

Kitchen HUD cursor: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_cursor_85e959de"]



Java target: 1.21.4 item model format (pack format 46 by default). A custom block asset is an item/display model unless a vanilla texture binding is set.