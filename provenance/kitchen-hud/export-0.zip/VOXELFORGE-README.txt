My resource pack

Enable the resource pack, then use these commands:

Kitchen HUD frame: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_frame_d5d8963a"]

Kitchen HUD letter_102: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_102_29e13183"]

Kitchen HUD letter_101: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_101_6aec04cd"]

Kitchen HUD letter_100: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_100_3e2843a4"]

Kitchen HUD letter_99: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_99_53609d0d"]

Kitchen HUD letter_98: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_98_4ff2f91e"]

Kitchen HUD letter_97: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_97_4cebf1af"]

Kitchen HUD letter_96: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_96_79f6d78e"]

Kitchen HUD letter_95: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_95_6f433161"]

Kitchen HUD letter_94: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_94_ba082d2e"]

Kitchen HUD letter_93: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_93_45b025e1"]

Kitchen HUD letter_92: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_92_80aafb77"]

Kitchen HUD letter_91: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_91_c7248b88"]

Kitchen HUD letter_90: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_90_4d9cbc06"]

Kitchen HUD letter_89: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_89_076e8292"]

Kitchen HUD letter_88: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_88_2208929e"]

Kitchen HUD letter_87: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_87_47a94875"]

Kitchen HUD letter_86: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_86_e7366ff5"]

Kitchen HUD letter_85: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_85_d0eb7f3b"]

Kitchen HUD letter_84: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_84_ef696850"]

Kitchen HUD letter_83: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_83_bb4938d3"]

Kitchen HUD letter_82: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_82_9217b0dd"]

Kitchen HUD letter_81: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_81_eed7e675"]

Kitchen HUD letter_80: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_80_b39585d5"]

Kitchen HUD letter_79: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_79_bdb37caf"]

Kitchen HUD letter_78: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_78_fe6e72a3"]

Kitchen HUD letter_77: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_77_4720b7d3"]

Kitchen HUD letter_76: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_76_3fdd6e70"]

Kitchen HUD letter_75: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_75_4292053e"]

Kitchen HUD letter_74: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_74_18619a6a"]

Kitchen HUD letter_73: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_73_e65a3462"]

Kitchen HUD letter_72: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_72_5d686bed"]

Kitchen HUD letter_71: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_71_3402a43f"]

Kitchen HUD letter_70: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_70_68056015"]

Kitchen HUD letter_69: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_69_559ac58f"]

Kitchen HUD letter_68: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_68_dad9e896"]

Kitchen HUD letter_67: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_67_ce14db9e"]

Kitchen HUD letter_66: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_66_fa085c2c"]

Kitchen HUD letter_65: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_65_1ccbead8"]

Kitchen HUD letter_64: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_64_9e7cc4f5"]

Kitchen HUD letter_63: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_63_3e8e49ba"]

Kitchen HUD letter_62: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_62_aa30a615"]

Kitchen HUD letter_61: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_61_24c79ee7"]

Kitchen HUD letter_60: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_60_b7ac3987"]

Kitchen HUD letter_59: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_59_1661fc19"]

Kitchen HUD letter_58: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_58_86288ada"]

Kitchen HUD letter_57: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_57_0863a7fd"]

Kitchen HUD letter_56: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_56_66b320e4"]

Kitchen HUD letter_55: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_55_48fdbde4"]

Kitchen HUD letter_54: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_54_ec2831a3"]

Kitchen HUD letter_53: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_53_4e613bb8"]

Kitchen HUD letter_52: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_52_abf13fe2"]

Kitchen HUD letter_51: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_51_8c4fc742"]

Kitchen HUD letter_50: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_50_4cb2d783"]

Kitchen HUD letter_49: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_49_7ed35cea"]

Kitchen HUD letter_48: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_48_3cfb113e"]

Kitchen HUD letter_47: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_47_a8b93b15"]

Kitchen HUD letter_46: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_46_690c0c5c"]

Kitchen HUD letter_45: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_45_b65ab591"]

Kitchen HUD letter_44: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_44_2df58cd4"]

Kitchen HUD letter_43: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_43_63b14054"]

Kitchen HUD letter_42: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_42_5f43047f"]

Kitchen HUD letter_41: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_41_74de7f21"]

Kitchen HUD letter_40: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_40_a84233fb"]

Kitchen HUD letter_39: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_39_6bc87d11"]

Kitchen HUD letter_38: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_38_d3142cab"]

Kitchen HUD letter_37: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_37_74d3e7f7"]

Kitchen HUD letter_36: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_36_d0832b2a"]

Kitchen HUD letter_35: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_35_41ffcea6"]

Kitchen HUD letter_34: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_34_7abf6f19"]

Kitchen HUD letter_33: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_33_78e55b5b"]

Kitchen HUD path: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_path_a13f82f3"]

Kitchen HUD basket: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_basket_9cd434b6"]

Kitchen HUD success: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_success_bedc4cb9"]

Kitchen HUD needle: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_needle_dbc5b730"]

Kitchen HUD target: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_target_373da769"]

Kitchen HUD green: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_green_7344377a"]

Kitchen HUD meter: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_meter_898075a9"]

Kitchen HUD hover_button: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_hover_button_54f31e6d"]

Kitchen HUD button: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_button_08634ed9"]

Kitchen HUD board: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_board_a699fc80"]

Kitchen HUD hover_card: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_hover_card_eed9e26f"]

Kitchen HUD card: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_card_faec3f1f"]

Kitchen HUD tool_15: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_15_c38d7f27"]

Kitchen HUD tool_14: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_14_1d979924"]

Kitchen HUD tool_13: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_13_36632afb"]

Kitchen HUD tool_12: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_12_ed351388"]

Kitchen HUD tool_11: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_11_a06127cb"]

Kitchen HUD tool_10: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_10_35312bf7"]

Kitchen HUD tool_9: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_9_8b9c9fa3"]

Kitchen HUD tool_8: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_8_49bbb206"]

Kitchen HUD tool_7: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_7_c09b8d78"]

Kitchen HUD tool_6: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_6_699acf2e"]

Kitchen HUD tool_5: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_5_40b1a092"]

Kitchen HUD tool_4: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_4_b4f3cc0e"]

Kitchen HUD tool_3: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_3_a7b25d62"]

Kitchen HUD tool_2: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_2_3d5c8a48"]

Kitchen HUD tool_1: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_1_b8f7cdc2"]

Kitchen HUD tool_0: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_tool_0_1303e1a8"]

Kitchen HUD cursor: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_cursor_85e959de"]



Java target: 1.21.4 item model format (pack format 46 by default). A custom block asset is an item/display model unless a vanilla texture binding is set.