My resource pack

Enable the resource pack, then use these commands:

Kitchen HUD icon_coffee_grounds_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_coffee_grounds_silh_6a3c14e8"]

Kitchen HUD icon_coffee_grounds_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_coffee_grounds_silh_0927d66b"]

Kitchen HUD icon_nori_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_nori_silhouette_lar_70196e4c"]

Kitchen HUD icon_nori_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_nori_silhouette_397cd81b"]

Kitchen HUD icon_salt_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_salt_silhouette_lar_44053e0a"]

Kitchen HUD icon_salt_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_salt_silhouette_1ab689eb"]

Kitchen HUD icon_flour_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_flour_silhouette_la_aa4759c9"]

Kitchen HUD icon_flour_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_flour_silhouette_3804a732"]

Kitchen HUD icon_tomato_seeds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_tomato_seeds_large_f4225f2f"]

Kitchen HUD icon_tomato_seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_tomato_seeds_6c5815cc"]

Kitchen HUD icon_strawberry_seeds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_strawberry_seeds_la_b929f24d"]

Kitchen HUD icon_strawberry_seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_strawberry_seeds_ef86cee8"]

Kitchen HUD icon_soy_seeds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_soy_seeds_large_765a5cbe"]

Kitchen HUD icon_soy_seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_soy_seeds_3091afbc"]

Kitchen HUD icon_salt_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_salt_large_486736fa"]

Kitchen HUD icon_salt: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_salt_aadf0dda"]

Kitchen HUD icon_rice_seeds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_rice_seeds_large_85d8dda6"]

Kitchen HUD icon_rice_seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_rice_seeds_a6de956a"]

Kitchen HUD icon_orange_seeds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_orange_seeds_large_9c2cc09b"]

Kitchen HUD icon_orange_seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_orange_seeds_c0f175f8"]

Kitchen HUD icon_onion_seeds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_onion_seeds_large_d471e986"]

Kitchen HUD icon_onion_seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_onion_seeds_29e58a8f"]

Kitchen HUD icon_nori_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_nori_large_1fc1c1b6"]

Kitchen HUD icon_nori: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_nori_8cff5eb7"]

Kitchen HUD icon_lettuce_seeds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_lettuce_seeds_large_e3af3260"]

Kitchen HUD icon_lettuce_seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_lettuce_seeds_2f1ad002"]

Kitchen HUD icon_lemon_seeds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_lemon_seeds_large_427e97e5"]

Kitchen HUD icon_lemon_seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_lemon_seeds_7b31485d"]

Kitchen HUD icon_garlic_seeds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_garlic_seeds_large_c4a0b13a"]

Kitchen HUD icon_garlic_seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_garlic_seeds_d00774bc"]

Kitchen HUD icon_flour_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_flour_large_86f01fe9"]

Kitchen HUD icon_flour: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_flour_0f4b9a79"]

Kitchen HUD icon_cucumber_seeds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cucumber_seeds_larg_00829dad"]

Kitchen HUD icon_cucumber_seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cucumber_seeds_43bc73f9"]

Kitchen HUD icon_corn_seeds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_corn_seeds_large_9ae368fb"]

Kitchen HUD icon_corn_seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_corn_seeds_165c5c4c"]

Kitchen HUD icon_coffee_seeds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_coffee_seeds_large_786fe0e0"]

Kitchen HUD icon_coffee_seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_coffee_seeds_0af66cb0"]

Kitchen HUD icon_coffee_grounds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_coffee_grounds_larg_75864d16"]

Kitchen HUD icon_coffee_grounds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_coffee_grounds_db489cf0"]

Kitchen HUD icon_chilli_seeds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chilli_seeds_large_04fb99ac"]

Kitchen HUD icon_chilli_seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chilli_seeds_0ec1eda7"]



Java target: 1.21.4 item model format (pack format 46 by default). A custom block asset is an item/display model unless a vanilla texture binding is set.