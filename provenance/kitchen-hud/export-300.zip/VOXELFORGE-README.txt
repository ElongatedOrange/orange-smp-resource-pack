My resource pack

Enable the resource pack, then use these commands:

Kitchen HUD icon_pork_dumplings: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_pork_dumplings_53b00d03"]

Kitchen HUD icon_beef_noodles_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_beef_noodles_large_19ca1b6b"]

Kitchen HUD icon_beef_noodles: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_beef_noodles_ebd8fdd5"]

Kitchen HUD icon_vegetable_noodles_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_vegetable_noodles_l_84f5df7f"]

Kitchen HUD icon_vegetable_noodles: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_vegetable_noodles_26e0bea9"]

Kitchen HUD icon_chicken_fried_rice_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chicken_fried_rice__e6ea7c7a"]

Kitchen HUD icon_chicken_fried_rice: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chicken_fried_rice_1739ede7"]

Kitchen HUD icon_egg_fried_rice_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_egg_fried_rice_larg_02b02757"]

Kitchen HUD icon_egg_fried_rice: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_egg_fried_rice_b6e217f1"]

Kitchen HUD icon_spicy_ramen_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_spicy_ramen_large_7ad647e5"]

Kitchen HUD icon_spicy_ramen: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_spicy_ramen_bdc6fb2a"]

Kitchen HUD icon_mushroom_ramen_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_mushroom_ramen_larg_6fc8220a"]

Kitchen HUD icon_mushroom_ramen: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_mushroom_ramen_b3edc5d8"]

Kitchen HUD icon_chicken_ramen_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chicken_ramen_large_d65dbf22"]

Kitchen HUD icon_chicken_ramen: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chicken_ramen_3641c740"]

Kitchen HUD icon_pancakes_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_pancakes_large_e4f12dc4"]

Kitchen HUD icon_pancakes: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_pancakes_ed609fd9"]

Kitchen HUD icon_chocolate_cake_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chocolate_cake_larg_e7883e8c"]

Kitchen HUD icon_chocolate_cake: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chocolate_cake_747a88c9"]

Kitchen HUD icon_strawberry_cake_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_strawberry_cake_lar_b4bf376c"]

Kitchen HUD icon_strawberry_cake: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_strawberry_cake_65a7f102"]

Kitchen HUD icon_berry_pie_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_berry_pie_large_2bc51eb9"]

Kitchen HUD icon_berry_pie: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_berry_pie_1a686086"]

Kitchen HUD icon_apple_pie_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_apple_pie_large_008b46cb"]

Kitchen HUD icon_apple_pie: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_apple_pie_86112ca6"]

Kitchen HUD icon_chocolate_cookie_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chocolate_cookie_la_0f194380"]

Kitchen HUD icon_chocolate_cookie: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chocolate_cookie_130c2af4"]

Kitchen HUD icon_sweet_roll_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_sweet_roll_large_3798c33d"]

Kitchen HUD icon_sweet_roll: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_sweet_roll_44383f5b"]

Kitchen HUD icon_strawberry_doughnut_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_strawberry_doughnut_fcfb0cd2"]

Kitchen HUD icon_strawberry_doughnut: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_strawberry_doughnut_f9250b7f"]

Kitchen HUD icon_chocolate_doughnut_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chocolate_doughnut__3b3ebb00"]

Kitchen HUD icon_chocolate_doughnut: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chocolate_doughnut_465fae5a"]

Kitchen HUD icon_glazed_doughnut_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_glazed_doughnut_lar_b98cedd4"]

Kitchen HUD icon_glazed_doughnut: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_glazed_doughnut_37f97059"]

Kitchen HUD icon_chocolate_croissant_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chocolate_croissant_58d69765"]

Kitchen HUD icon_chocolate_croissant: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chocolate_croissant_12ebf5fa"]

Kitchen HUD icon_croissant_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_croissant_large_0dc33459"]

Kitchen HUD icon_croissant: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_croissant_feea933c"]

Kitchen HUD icon_garlic_bread_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_garlic_bread_large_7a4450b0"]

Kitchen HUD icon_garlic_bread: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_garlic_bread_655ddb19"]

Kitchen HUD icon_calzone_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_calzone_large_cbe5b9b1"]

Kitchen HUD icon_calzone: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_calzone_da45a0d7"]

Kitchen HUD icon_chilli_pizza_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chilli_pizza_large_11c26646"]

Kitchen HUD icon_chilli_pizza: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chilli_pizza_b8cf6a2a"]

Kitchen HUD icon_bbq_chicken_pizza_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_bbq_chicken_pizza_l_ef16c93c"]

Kitchen HUD icon_bbq_chicken_pizza: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_bbq_chicken_pizza_6eb12a35"]

Kitchen HUD icon_garden_pizza_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_garden_pizza_large_21b81005"]

Kitchen HUD icon_garden_pizza: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_garden_pizza_175cca91"]

Kitchen HUD icon_mushroom_pizza_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_mushroom_pizza_larg_b65634a0"]

Kitchen HUD icon_mushroom_pizza: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_mushroom_pizza_dda09b57"]

Kitchen HUD icon_pepperoni_pizza_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_pepperoni_pizza_lar_489826f5"]

Kitchen HUD icon_pepperoni_pizza: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_pepperoni_pizza_54962f54"]

Kitchen HUD icon_margherita_pizza_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_margherita_pizza_la_7513476d"]

Kitchen HUD icon_margherita_pizza: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_margherita_pizza_fa6e6239"]

Kitchen HUD icon_sushi_platter_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_sushi_platter_large_58b1575f"]

Kitchen HUD icon_sushi_platter: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_sushi_platter_aba500f4"]

Kitchen HUD icon_vegetable_tempura_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_vegetable_tempura_l_6d61cc1e"]

Kitchen HUD icon_vegetable_tempura: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_vegetable_tempura_a2a50153"]

Kitchen HUD icon_salmon_onigiri_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_salmon_onigiri_larg_18c03549"]

Kitchen HUD icon_salmon_onigiri: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_salmon_onigiri_18466d58"]

Kitchen HUD icon_onigiri_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_onigiri_large_b9287156"]

Kitchen HUD icon_onigiri: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_onigiri_a043b115"]

Kitchen HUD icon_garden_roll_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_garden_roll_large_23636ace"]

Kitchen HUD icon_garden_roll: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_garden_roll_37336594"]

Kitchen HUD icon_spicy_salmon_roll_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_spicy_salmon_roll_l_ea1a405f"]

Kitchen HUD icon_spicy_salmon_roll: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_spicy_salmon_roll_784af7e6"]

Kitchen HUD icon_salmon_maki_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_salmon_maki_large_003d1cb4"]

Kitchen HUD icon_salmon_maki: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_salmon_maki_c42e7c38"]

Kitchen HUD icon_cucumber_maki_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cucumber_maki_large_62dab494"]

Kitchen HUD icon_cucumber_maki: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cucumber_maki_9fa25c69"]

Kitchen HUD icon_cod_nigiri_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cod_nigiri_large_397d67fe"]

Kitchen HUD icon_cod_nigiri: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cod_nigiri_7466ae70"]

Kitchen HUD icon_salmon_nigiri_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_salmon_nigiri_large_7768f426"]

Kitchen HUD icon_salmon_nigiri: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_salmon_nigiri_f7edc627"]

Kitchen HUD icon_fish_burger_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_fish_burger_large_9a0a2e61"]

Kitchen HUD icon_fish_burger: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_fish_burger_68e9ed16"]

Kitchen HUD icon_chicken_nuggets_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chicken_nuggets_lar_d29a9624"]

Kitchen HUD icon_chicken_nuggets: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chicken_nuggets_86e50a27"]

Kitchen HUD icon_onion_rings_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_onion_rings_large_b939a26c"]

Kitchen HUD icon_onion_rings: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_onion_rings_bc640523"]

Kitchen HUD icon_loaded_fries_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_loaded_fries_large_ceb44883"]

Kitchen HUD icon_loaded_fries: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_loaded_fries_b48e825b"]

Kitchen HUD icon_fries_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_fries_large_beea5fd7"]

Kitchen HUD icon_fries: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_fries_710c56c5"]

Kitchen HUD icon_chilli_dog_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chilli_dog_large_3ae22fa1"]

Kitchen HUD icon_chilli_dog: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chilli_dog_70cb2797"]

Kitchen HUD icon_hot_dog_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_hot_dog_large_d1611676"]

Kitchen HUD icon_hot_dog: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_hot_dog_c69001bb"]

Kitchen HUD icon_veggie_burger_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_veggie_burger_large_171cae57"]

Kitchen HUD icon_veggie_burger: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_veggie_burger_8825f64c"]

Kitchen HUD icon_spicy_chicken_burger_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_spicy_chicken_burge_40496a70"]

Kitchen HUD icon_spicy_chicken_burger: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_spicy_chicken_burge_48104dcc"]

Kitchen HUD icon_chicken_burger_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chicken_burger_larg_81efd8d4"]

Kitchen HUD icon_chicken_burger: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chicken_burger_2f64c0f6"]

Kitchen HUD icon_double_burger_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_double_burger_large_4b5c67ce"]

Kitchen HUD icon_double_burger: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_double_burger_a3ac7339"]

Kitchen HUD icon_cheeseburger_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cheeseburger_large_c3d3d354"]

Kitchen HUD icon_cheeseburger: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cheeseburger_3a4f3c22"]

Kitchen HUD icon_coffee_grounds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_coffee_grounds_larg_8e3ba12d"]



Java target: 1.21.4 item model format (pack format 46 by default). A custom block asset is an item/display model unless a vanilla texture binding is set.