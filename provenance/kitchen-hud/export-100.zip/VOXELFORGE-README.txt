My resource pack

Enable the resource pack, then use these commands:

Kitchen HUD letter_126: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_126_123b25c5"]

Kitchen HUD letter_125: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_125_47d05dd7"]

Kitchen HUD letter_124: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_124_75720da2"]

Kitchen HUD letter_123: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_123_6b3f1f48"]

Kitchen HUD letter_122: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_122_a4184b53"]

Kitchen HUD letter_121: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_121_19e45686"]

Kitchen HUD letter_120: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_120_cd6c0a1d"]

Kitchen HUD letter_119: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_119_c66a85d1"]

Kitchen HUD letter_118: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_118_4a284b1e"]

Kitchen HUD letter_117: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_117_8e873944"]

Kitchen HUD letter_116: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_116_854e9bb4"]

Kitchen HUD letter_115: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_115_b45698a2"]

Kitchen HUD letter_114: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_114_cdaa93a2"]

Kitchen HUD letter_113: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_113_7ed461c4"]

Kitchen HUD letter_112: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_112_3dc80788"]

Kitchen HUD letter_111: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_111_79bc77ce"]

Kitchen HUD letter_110: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_110_507b066c"]

Kitchen HUD letter_109: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_109_f759aeb9"]

Kitchen HUD letter_108: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_108_f868e419"]

Kitchen HUD letter_107: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_107_95c54597"]

Kitchen HUD letter_106: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_106_c759ca77"]

Kitchen HUD letter_105: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_105_eab52c44"]

Kitchen HUD letter_104: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_104_61d411c3"]

Kitchen HUD letter_103: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_103_9661a703"]



Java target: 1.21.4 item model format (pack format 46 by default). A custom block asset is an item/display model unless a vanilla texture binding is set.