My resource pack

Enable the resource pack, then use these commands:

Kitchen HUD icon_coffee_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_coffee_large_ed5ae694"]

Kitchen HUD icon_coffee: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_coffee_1fb9692c"]

Kitchen HUD icon_soy_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_soy_large_d5e5e0d1"]

Kitchen HUD icon_soy: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_soy_dbd58ed1"]

Kitchen HUD icon_strawberry_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_strawberry_large_1f5b6ac8"]

Kitchen HUD icon_strawberry: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_strawberry_a360e577"]

Kitchen HUD icon_corn_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_corn_large_2ccb32f7"]

Kitchen HUD icon_corn: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_corn_ddc96a70"]

Kitchen HUD icon_cucumber_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cucumber_large_96369152"]

Kitchen HUD icon_cucumber: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cucumber_d06dddd9"]

Kitchen HUD icon_chilli_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chilli_large_3ed4458d"]

Kitchen HUD icon_chilli: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chilli_70c80957"]

Kitchen HUD icon_rice_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_rice_large_15ce7e5a"]

Kitchen HUD icon_rice: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_rice_6e520121"]

Kitchen HUD icon_onion_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_onion_large_b931a938"]

Kitchen HUD icon_onion: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_onion_ac1d4655"]

Kitchen HUD icon_lettuce_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_lettuce_large_83e3757e"]

Kitchen HUD icon_lettuce: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_lettuce_176b9e3e"]

Kitchen HUD icon_tomato_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_tomato_large_87a88c4b"]

Kitchen HUD icon_tomato: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_tomato_042c90d8"]

Kitchen HUD icon_takeaway_bag_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_takeaway_bag_large_98c61edb"]

Kitchen HUD icon_takeaway_bag: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_takeaway_bag_af318779"]

Kitchen HUD icon_plate_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_plate_large_b9c5811e"]

Kitchen HUD icon_plate: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_plate_6cee74c7"]

Kitchen HUD icon_cookbook_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cookbook_large_0a7f0a07"]

Kitchen HUD icon_cookbook: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cookbook_97acf6bf"]

Kitchen HUD icon_coffee_machine_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_coffee_machine_larg_b8412632"]

Kitchen HUD icon_coffee_machine: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_coffee_machine_5d1a9be6"]

Kitchen HUD icon_blender_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_blender_large_b43ea251"]

Kitchen HUD icon_blender: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_blender_fec7c0d6"]

Kitchen HUD icon_smoker_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_smoker_large_23de7174"]

Kitchen HUD icon_smoker: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_smoker_f1accee2"]

Kitchen HUD icon_steamer_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_steamer_large_d1f49d14"]

Kitchen HUD icon_steamer: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_steamer_b42c43e9"]

Kitchen HUD icon_wok_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_wok_large_6563ddad"]

Kitchen HUD icon_wok: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_wok_3a3e35eb"]

Kitchen HUD icon_stockpot_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_stockpot_large_721fa69a"]

Kitchen HUD icon_stockpot: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_stockpot_d04ba2f7"]

Kitchen HUD icon_baking_oven_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_baking_oven_large_c8e216ca"]

Kitchen HUD icon_baking_oven: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_baking_oven_80ca0823"]

Kitchen HUD icon_pizza_oven_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_pizza_oven_large_4b1f5c39"]

Kitchen HUD icon_pizza_oven: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_pizza_oven_62e4e949"]

Kitchen HUD icon_dough_bench_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_dough_bench_large_54391528"]

Kitchen HUD icon_dough_bench: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_dough_bench_4d222d59"]

Kitchen HUD icon_sushi_counter_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_sushi_counter_large_f464be74"]

Kitchen HUD icon_sushi_counter: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_sushi_counter_cdcc3772"]

Kitchen HUD icon_rice_cooker_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_rice_cooker_large_27966372"]

Kitchen HUD icon_rice_cooker: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_rice_cooker_8592d7d5"]

Kitchen HUD icon_deep_fryer_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_deep_fryer_large_4046b5c3"]

Kitchen HUD icon_deep_fryer: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_deep_fryer_0adedb04"]

Kitchen HUD icon_griddle_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_griddle_large_0afa0241"]

Kitchen HUD icon_griddle: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_griddle_15944105"]

Kitchen HUD icon_mixing_bowl_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_mixing_bowl_large_89986bfa"]

Kitchen HUD icon_mixing_bowl: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_mixing_bowl_1e727ff1"]

Kitchen HUD icon_chopping_board_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chopping_board_larg_3e513f38"]

Kitchen HUD icon_chopping_board: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chopping_board_e1c41cf8"]

Kitchen HUD icon_prep_counter_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_prep_counter_large_47d1af6b"]

Kitchen HUD icon_prep_counter: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_prep_counter_fece3e86"]

Kitchen HUD icon_soy_seeds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_soy_seeds_large_a126e60f"]

Kitchen HUD icon_soy_seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_soy_seeds_7d97fe19"]

Kitchen HUD icon_strawberry_seeds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_strawberry_seeds_la_3faebb8c"]

Kitchen HUD icon_strawberry_seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_strawberry_seeds_6b067dc5"]

Kitchen HUD icon_corn_seeds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_corn_seeds_large_70dbe266"]

Kitchen HUD icon_corn_seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_corn_seeds_e442df15"]

Kitchen HUD icon_cucumber_seeds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cucumber_seeds_larg_4d2b96bd"]

Kitchen HUD icon_cucumber_seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cucumber_seeds_473a7db9"]

Kitchen HUD icon_chilli_seeds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chilli_seeds_large_605e57f8"]

Kitchen HUD icon_chilli_seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chilli_seeds_3642235e"]

Kitchen HUD icon_rice_seeds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_rice_seeds_large_070fa5f0"]

Kitchen HUD icon_rice_seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_rice_seeds_b31ae1e8"]

Kitchen HUD icon_onion_seeds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_onion_seeds_large_bfbac578"]

Kitchen HUD icon_onion_seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_onion_seeds_8c6414c4"]

Kitchen HUD icon_lettuce_seeds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_lettuce_seeds_large_00d563e6"]

Kitchen HUD icon_lettuce_seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_lettuce_seeds_4780b664"]

Kitchen HUD icon_tomato_seeds_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_tomato_seeds_large_3b435a0f"]

Kitchen HUD icon_tomato_seeds: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_tomato_seeds_8ab14a46"]

Kitchen HUD letter_126: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_126_b2ea50a9"]

Kitchen HUD letter_125: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_125_ec3e7d77"]

Kitchen HUD letter_124: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_124_bc975bb7"]

Kitchen HUD letter_123: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_123_29524f2a"]

Kitchen HUD letter_122: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_122_e85184e3"]

Kitchen HUD letter_121: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_121_527d8ba8"]

Kitchen HUD letter_120: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_120_78019969"]

Kitchen HUD letter_119: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_119_e8dc9457"]

Kitchen HUD letter_118: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_118_dbe9e156"]

Kitchen HUD letter_117: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_117_23f8c8fb"]

Kitchen HUD letter_116: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_116_7f38dffc"]

Kitchen HUD letter_115: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_115_c04614fe"]

Kitchen HUD letter_114: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_114_75b0cc02"]

Kitchen HUD letter_113: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_113_4a4d0dd3"]

Kitchen HUD letter_112: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_112_64eabadc"]

Kitchen HUD letter_111: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_111_2a9e40f0"]

Kitchen HUD letter_110: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_110_1e851fb0"]

Kitchen HUD letter_109: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_109_51cab7d6"]

Kitchen HUD letter_108: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_108_82e6d31f"]

Kitchen HUD letter_107: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_107_02838d84"]

Kitchen HUD letter_106: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_106_da817174"]

Kitchen HUD letter_105: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_105_8140636b"]

Kitchen HUD letter_104: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_104_66fdab8d"]

Kitchen HUD letter_103: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_letter_103_bfbe37ad"]



Java target: 1.21.4 item model format (pack format 46 by default). A custom block asset is an item/display model unless a vanilla texture binding is set.