My resource pack

Enable the resource pack, then use these commands:

Kitchen HUD icon_chilli_dog_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chilli_dog_silhouet_59cf21d4"]

Kitchen HUD icon_chilli_dog_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chilli_dog_silhouet_c5d2bc34"]

Kitchen HUD icon_hot_dog_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_hot_dog_silhouette__9d4bb004"]

Kitchen HUD icon_hot_dog_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_hot_dog_silhouette_62c1304e"]

Kitchen HUD icon_veggie_burger_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_veggie_burger_silho_2dc79252"]

Kitchen HUD icon_veggie_burger_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_veggie_burger_silho_20e65d4d"]

Kitchen HUD icon_spicy_chicken_burger_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_spicy_chicken_burge_24441058"]

Kitchen HUD icon_spicy_chicken_burger_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_spicy_chicken_burge_345d66f5"]

Kitchen HUD icon_chicken_burger_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chicken_burger_silh_3b0797fc"]

Kitchen HUD icon_chicken_burger_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chicken_burger_silh_5986f924"]

Kitchen HUD icon_double_burger_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_double_burger_silho_6d13d443"]

Kitchen HUD icon_double_burger_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_double_burger_silho_6063f98a"]

Kitchen HUD icon_cheeseburger_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cheeseburger_silhou_7a82d1eb"]

Kitchen HUD icon_cheeseburger_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cheeseburger_silhou_4986511d"]

Kitchen HUD icon_pulled_pork_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_pulled_pork_silhoue_ddad17c6"]

Kitchen HUD icon_pulled_pork_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_pulled_pork_silhoue_07b5e16b"]

Kitchen HUD icon_fried_fish_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_fried_fish_silhouet_46606b57"]

Kitchen HUD icon_fried_fish_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_fried_fish_silhouet_8be03043"]

Kitchen HUD icon_fried_chicken_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_fried_chicken_silho_8b0efb39"]

Kitchen HUD icon_fried_chicken_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_fried_chicken_silho_a93a67b0"]

Kitchen HUD icon_cooked_chicken_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cooked_chicken_silh_f5e58843"]

Kitchen HUD icon_cooked_chicken_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cooked_chicken_silh_93b61418"]

Kitchen HUD icon_sushi_rice_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_sushi_rice_silhouet_a7bb9bdf"]

Kitchen HUD icon_sushi_rice_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_sushi_rice_silhouet_a217e24d"]

Kitchen HUD icon_bbq_sauce_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_bbq_sauce_silhouett_551227fd"]

Kitchen HUD icon_bbq_sauce_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_bbq_sauce_silhouett_3edc9e09"]

Kitchen HUD icon_sliced_potato_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_sliced_potato_silho_644576da"]

Kitchen HUD icon_sliced_potato_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_sliced_potato_silho_9f50c033"]

Kitchen HUD icon_pepperoni_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_pepperoni_silhouett_c821cbd7"]

Kitchen HUD icon_pepperoni_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_pepperoni_silhouett_20e8ee68"]

Kitchen HUD icon_sausage_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_sausage_silhouette__76c9e64d"]

Kitchen HUD icon_sausage_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_sausage_silhouette_1f67b3f0"]

Kitchen HUD icon_broth_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_broth_silhouette_la_1252ae56"]

Kitchen HUD icon_broth_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_broth_silhouette_11baef60"]

Kitchen HUD icon_chocolate_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chocolate_silhouett_e2dd1727"]

Kitchen HUD icon_chocolate_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chocolate_silhouett_5fb1f10e"]

Kitchen HUD icon_cream_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cream_silhouette_la_5866390b"]

Kitchen HUD icon_cream_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cream_silhouette_85744e58"]

Kitchen HUD icon_soy_sauce_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_soy_sauce_silhouett_b25692d1"]

Kitchen HUD icon_soy_sauce_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_soy_sauce_silhouett_dcb75d26"]

Kitchen HUD icon_hot_sauce_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_hot_sauce_silhouett_99349b2a"]

Kitchen HUD icon_hot_sauce_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_hot_sauce_silhouett_d362cfcd"]

Kitchen HUD icon_tomato_sauce_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_tomato_sauce_silhou_e77095fc"]

Kitchen HUD icon_tomato_sauce_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_tomato_sauce_silhou_f0e29afe"]

Kitchen HUD icon_pizza_base_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_pizza_base_silhouet_b38e788c"]

Kitchen HUD icon_pizza_base_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_pizza_base_silhouet_d57a8261"]

Kitchen HUD icon_noodles_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_noodles_silhouette__6b49d07c"]

Kitchen HUD icon_noodles_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_noodles_silhouette_774bac29"]

Kitchen HUD icon_bun_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_bun_silhouette_larg_5bd8d5aa"]

Kitchen HUD icon_bun_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_bun_silhouette_371b7c89"]

Kitchen HUD icon_burger_patty_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_burger_patty_silhou_9a1bc9f2"]

Kitchen HUD icon_burger_patty_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_burger_patty_silhou_f0537df8"]

Kitchen HUD icon_raw_patty_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_raw_patty_silhouett_f41dea3c"]

Kitchen HUD icon_raw_patty_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_raw_patty_silhouett_83d6ef7b"]

Kitchen HUD icon_minced_beef_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minced_beef_silhoue_c07bcb20"]

Kitchen HUD icon_minced_beef_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_minced_beef_silhoue_aeab1f53"]

Kitchen HUD icon_cod_slice_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cod_slice_silhouett_fb984bde"]

Kitchen HUD icon_cod_slice_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cod_slice_silhouett_81e032bf"]

Kitchen HUD icon_salmon_slice_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_salmon_slice_silhou_d742aec2"]

Kitchen HUD icon_salmon_slice_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_salmon_slice_silhou_c83d1c7a"]

Kitchen HUD icon_cooked_rice_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cooked_rice_silhoue_503dba28"]

Kitchen HUD icon_cooked_rice_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cooked_rice_silhoue_3940c763"]

Kitchen HUD icon_breadcrumbs_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_breadcrumbs_silhoue_808ddf91"]

Kitchen HUD icon_breadcrumbs_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_breadcrumbs_silhoue_3bc004f8"]

Kitchen HUD icon_batter_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_batter_silhouette_l_fcab5cf2"]

Kitchen HUD icon_batter_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_batter_silhouette_54db703d"]

Kitchen HUD icon_dough_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_dough_silhouette_la_90e0dc87"]

Kitchen HUD icon_dough_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_dough_silhouette_276ebc23"]

Kitchen HUD icon_cheese_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cheese_silhouette_l_a7e82df4"]

Kitchen HUD icon_cheese_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cheese_silhouette_ed9adb0f"]

Kitchen HUD icon_butter_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_butter_silhouette_l_0900421e"]

Kitchen HUD icon_butter_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_butter_silhouette_2bc0c2d9"]

Kitchen HUD icon_hot_chocolate_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_hot_chocolate_large_48d79892"]

Kitchen HUD icon_hot_chocolate: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_hot_chocolate_7cdb3296"]

Kitchen HUD icon_mocha_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_mocha_large_b15be3fd"]

Kitchen HUD icon_mocha: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_mocha_590c7917"]

Kitchen HUD icon_latte_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_latte_large_673b9aa5"]

Kitchen HUD icon_latte: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_latte_88aed680"]

Kitchen HUD icon_espresso_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_espresso_large_aa3bf455"]

Kitchen HUD icon_espresso: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_espresso_e3740360"]

Kitchen HUD icon_iced_coffee_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_iced_coffee_large_f3c25d5e"]

Kitchen HUD icon_iced_coffee: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_iced_coffee_a2baeb15"]

Kitchen HUD icon_berry_smoothie_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_berry_smoothie_larg_2bc56c6d"]

Kitchen HUD icon_berry_smoothie: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_berry_smoothie_48b208fe"]

Kitchen HUD icon_chocolate_milkshake_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chocolate_milkshake_dde030a6"]

Kitchen HUD icon_chocolate_milkshake: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chocolate_milkshake_16f37814"]

Kitchen HUD icon_strawberry_milkshake_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_strawberry_milkshak_521c0c1b"]

Kitchen HUD icon_strawberry_milkshake: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_strawberry_milkshak_c75df158"]

Kitchen HUD icon_lemonade_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_lemonade_large_ff2b6315"]

Kitchen HUD icon_lemonade: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_lemonade_a543c248"]

Kitchen HUD icon_orange_juice_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_orange_juice_large_36f50820"]

Kitchen HUD icon_orange_juice: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_orange_juice_2eca9df2"]

Kitchen HUD icon_coffee_grounds_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_coffee_grounds_silh_6d1444ba"]

Kitchen HUD icon_coffee_grounds_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_coffee_grounds_silh_0c2b402b"]

Kitchen HUD icon_nori_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_nori_silhouette_lar_ebf2b7f7"]

Kitchen HUD icon_nori_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_nori_silhouette_38131dfe"]

Kitchen HUD icon_salt_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_salt_silhouette_lar_a6b6f820"]

Kitchen HUD icon_salt_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_salt_silhouette_ff60244a"]

Kitchen HUD icon_flour_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_flour_silhouette_la_99fe9178"]

Kitchen HUD icon_flour_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_flour_silhouette_747d4aff"]



Java target: 1.21.4 item model format (pack format 46 by default). A custom block asset is an item/display model unless a vanilla texture binding is set.