My resource pack

Enable the resource pack, then use these commands:

Kitchen HUD icon_chicken_fried_rice_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chicken_fried_rice__51c913a7"]

Kitchen HUD icon_egg_fried_rice_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_egg_fried_rice_silh_18615506"]

Kitchen HUD icon_egg_fried_rice_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_egg_fried_rice_silh_c596b1e7"]

Kitchen HUD icon_spicy_ramen_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_spicy_ramen_silhoue_74ea81c4"]

Kitchen HUD icon_spicy_ramen_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_spicy_ramen_silhoue_c9bf8f7c"]

Kitchen HUD icon_mushroom_ramen_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_mushroom_ramen_silh_1ce23f60"]

Kitchen HUD icon_mushroom_ramen_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_mushroom_ramen_silh_e019bb65"]

Kitchen HUD icon_chicken_ramen_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chicken_ramen_silho_914749b0"]

Kitchen HUD icon_chicken_ramen_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chicken_ramen_silho_4dbf8363"]

Kitchen HUD icon_pancakes_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_pancakes_silhouette_35c51a8f"]

Kitchen HUD icon_pancakes_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_pancakes_silhouette_4c42565a"]

Kitchen HUD icon_chocolate_cake_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chocolate_cake_silh_927bcdea"]

Kitchen HUD icon_chocolate_cake_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chocolate_cake_silh_14b5f4a0"]

Kitchen HUD icon_strawberry_cake_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_strawberry_cake_sil_a95cb2f1"]

Kitchen HUD icon_strawberry_cake_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_strawberry_cake_sil_1ff462d2"]

Kitchen HUD icon_berry_pie_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_berry_pie_silhouett_2ae929be"]

Kitchen HUD icon_berry_pie_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_berry_pie_silhouett_a17c50ec"]

Kitchen HUD icon_apple_pie_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_apple_pie_silhouett_16c15bdb"]

Kitchen HUD icon_apple_pie_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_apple_pie_silhouett_be3679cb"]

Kitchen HUD icon_chocolate_cookie_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chocolate_cookie_si_e348a300"]

Kitchen HUD icon_chocolate_cookie_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chocolate_cookie_si_63e0fcbd"]

Kitchen HUD icon_sweet_roll_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_sweet_roll_silhouet_a9f0d26f"]

Kitchen HUD icon_sweet_roll_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_sweet_roll_silhouet_5388f210"]

Kitchen HUD icon_strawberry_doughnut_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_strawberry_doughnut_dfc09e7c"]

Kitchen HUD icon_strawberry_doughnut_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_strawberry_doughnut_87368e52"]

Kitchen HUD icon_chocolate_doughnut_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chocolate_doughnut__2ff3e478"]

Kitchen HUD icon_chocolate_doughnut_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chocolate_doughnut__4864b215"]

Kitchen HUD icon_glazed_doughnut_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_glazed_doughnut_sil_30a9dbd1"]

Kitchen HUD icon_glazed_doughnut_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_glazed_doughnut_sil_da43cadc"]

Kitchen HUD icon_chocolate_croissant_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chocolate_croissant_da4ec3dc"]

Kitchen HUD icon_chocolate_croissant_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chocolate_croissant_8e916651"]

Kitchen HUD icon_croissant_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_croissant_silhouett_c3b33298"]

Kitchen HUD icon_croissant_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_croissant_silhouett_e6dba4de"]

Kitchen HUD icon_garlic_bread_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_garlic_bread_silhou_8fd5c623"]

Kitchen HUD icon_garlic_bread_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_garlic_bread_silhou_d95b579a"]

Kitchen HUD icon_calzone_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_calzone_silhouette__b4bcafd2"]

Kitchen HUD icon_calzone_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_calzone_silhouette_30e7a208"]

Kitchen HUD icon_chilli_pizza_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chilli_pizza_silhou_9d1817b1"]

Kitchen HUD icon_chilli_pizza_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chilli_pizza_silhou_ca0e6a77"]

Kitchen HUD icon_bbq_chicken_pizza_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_bbq_chicken_pizza_s_024706f8"]

Kitchen HUD icon_bbq_chicken_pizza_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_bbq_chicken_pizza_s_47838573"]

Kitchen HUD icon_garden_pizza_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_garden_pizza_silhou_f3cd855c"]

Kitchen HUD icon_garden_pizza_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_garden_pizza_silhou_a17f3be0"]

Kitchen HUD icon_mushroom_pizza_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_mushroom_pizza_silh_0cdbf5b1"]

Kitchen HUD icon_mushroom_pizza_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_mushroom_pizza_silh_c5bd3f44"]

Kitchen HUD icon_pepperoni_pizza_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_pepperoni_pizza_sil_89f284cc"]

Kitchen HUD icon_pepperoni_pizza_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_pepperoni_pizza_sil_097d6165"]

Kitchen HUD icon_margherita_pizza_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_margherita_pizza_si_39e47676"]

Kitchen HUD icon_margherita_pizza_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_margherita_pizza_si_97e08d6d"]

Kitchen HUD icon_sushi_platter_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_sushi_platter_silho_59c15cbb"]

Kitchen HUD icon_sushi_platter_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_sushi_platter_silho_a915b8af"]

Kitchen HUD icon_vegetable_tempura_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_vegetable_tempura_s_61d40943"]

Kitchen HUD icon_vegetable_tempura_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_vegetable_tempura_s_15985613"]

Kitchen HUD icon_salmon_onigiri_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_salmon_onigiri_silh_213f87df"]

Kitchen HUD icon_salmon_onigiri_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_salmon_onigiri_silh_1d615e68"]

Kitchen HUD icon_onigiri_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_onigiri_silhouette__93488e3c"]

Kitchen HUD icon_onigiri_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_onigiri_silhouette_9de18a6d"]

Kitchen HUD icon_garden_roll_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_garden_roll_silhoue_9fc7ada3"]

Kitchen HUD icon_garden_roll_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_garden_roll_silhoue_1b1859cf"]

Kitchen HUD icon_spicy_salmon_roll_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_spicy_salmon_roll_s_6955f12b"]

Kitchen HUD icon_spicy_salmon_roll_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_spicy_salmon_roll_s_b7260bc1"]

Kitchen HUD icon_salmon_maki_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_salmon_maki_silhoue_7092f6a6"]

Kitchen HUD icon_salmon_maki_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_salmon_maki_silhoue_ab70f18a"]

Kitchen HUD icon_cucumber_maki_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cucumber_maki_silho_3f83d1ff"]

Kitchen HUD icon_cucumber_maki_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cucumber_maki_silho_2968ecd1"]

Kitchen HUD icon_cod_nigiri_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cod_nigiri_silhouet_3f790eda"]

Kitchen HUD icon_cod_nigiri_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cod_nigiri_silhouet_da9f53de"]

Kitchen HUD icon_salmon_nigiri_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_salmon_nigiri_silho_ee3eb6fd"]

Kitchen HUD icon_salmon_nigiri_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_salmon_nigiri_silho_964616dd"]

Kitchen HUD icon_fish_burger_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_fish_burger_silhoue_69b81c5c"]

Kitchen HUD icon_fish_burger_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_fish_burger_silhoue_ddae059e"]

Kitchen HUD icon_chicken_nuggets_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chicken_nuggets_sil_371e8e65"]

Kitchen HUD icon_chicken_nuggets_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chicken_nuggets_sil_476f0684"]

Kitchen HUD icon_onion_rings_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_onion_rings_silhoue_5a4d2377"]

Kitchen HUD icon_onion_rings_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_onion_rings_silhoue_0608c308"]

Kitchen HUD icon_loaded_fries_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_loaded_fries_silhou_20bbb444"]

Kitchen HUD icon_loaded_fries_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_loaded_fries_silhou_7d36d578"]

Kitchen HUD icon_fries_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_fries_silhouette_la_8efec139"]

Kitchen HUD icon_fries_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_fries_silhouette_d950e645"]

Kitchen HUD icon_chilli_dog_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chilli_dog_silhouet_59cf21d4"]

Kitchen HUD icon_chilli_dog_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chilli_dog_silhouet_c5d2bc34"]

Kitchen HUD icon_hot_dog_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_hot_dog_silhouette__9d4bb004"]

Kitchen HUD icon_hot_dog_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_hot_dog_silhouette_62c1304e"]

Kitchen HUD icon_veggie_burger_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_veggie_burger_silho_2dc79252"]

Kitchen HUD icon_veggie_burger_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_veggie_burger_silho_20e65d4d"]

Kitchen HUD icon_spicy_chicken_burger_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_spicy_chicken_burge_24441058"]

Kitchen HUD icon_spicy_chicken_burger_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_spicy_chicken_burge_345d66f5"]

Kitchen HUD icon_chicken_burger_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chicken_burger_silh_3b0797fc"]

Kitchen HUD icon_chicken_burger_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_chicken_burger_silh_5986f924"]

Kitchen HUD icon_double_burger_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_double_burger_silho_6d13d443"]

Kitchen HUD icon_double_burger_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_double_burger_silho_6063f98a"]

Kitchen HUD icon_cheeseburger_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cheeseburger_silhou_7a82d1eb"]

Kitchen HUD icon_cheeseburger_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_cheeseburger_silhou_4986511d"]

Kitchen HUD icon_pulled_pork_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_pulled_pork_silhoue_ddad17c6"]

Kitchen HUD icon_pulled_pork_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_pulled_pork_silhoue_07b5e16b"]

Kitchen HUD icon_fried_fish_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_fried_fish_silhouet_46606b57"]

Kitchen HUD icon_fried_fish_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_fried_fish_silhouet_8be03043"]

Kitchen HUD icon_fried_chicken_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_fried_chicken_silho_8b0efb39"]

Kitchen HUD icon_coffee_grounds_silhouette_large: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_coffee_grounds_silh_6d1444ba"]

Kitchen HUD icon_coffee_grounds_silhouette: /give @s minecraft:paper[minecraft:item_model="voxelforge:kitchen_hud_icon_coffee_grounds_silh_0c2b402b"]



Java target: 1.21.4 item model format (pack format 46 by default). A custom block asset is an item/display model unless a vanilla texture binding is set.